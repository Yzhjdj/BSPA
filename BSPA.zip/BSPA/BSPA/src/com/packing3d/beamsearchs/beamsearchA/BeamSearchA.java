package com.packing3d.beamsearchs.beamsearchA;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.state.State;
import com.packing3d.helper.BlockGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class BeamSearchA {
    public static State run(Problem problem, int timeLimit, double minFillRate, boolean isRuoYiGou){
        // 开辟一个final的对象数组,用于保存匿名内部类的里面的结果
        State[] bestState = new State[1];
        ArrayList<Block> blockList = BlockGenerator.complexBlocks(problem,10000,minFillRate); // 每个线程中的块表需要单独生成 否则多个线程中的块会被公用 而坐标出错
        // 生成初始状态
        State stateInit = new State(problem, blockList);
        System.out.println("BeamSearchA 初始状态生成完成，开始搜索");

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                int w = 1;
                while (true) {
                    beamSearchA(w, bestState, stateInit);
                    w = (int) Math.ceil(Math.sqrt(2) * w);
                }
            }
        });
        long start = System.currentTimeMillis();
        thread.start();
        try {
            TimeUnit.MILLISECONDS.sleep(timeLimit);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        thread.stop();
        System.out.println("运行时间:" + (System.currentTimeMillis() - start) + "ms");
        return bestState[0];
    }
    /**
     * @Author yajiewen
     * @Date 2022-10-03 09-43-50
     * @Description 将状态列表数据结构从HashSet 改为 ArrayList
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-03 10-17-01
     * @Description 优化，使得不需要每次在while循环中创建successor 和succ
     */
    public static void beamSearchA(int w, State[] bestState, State stateInit){
        // 定义一个state list
        ArrayList<State> stateList = new ArrayList<>();
        stateList.add(stateInit);

        ArrayList<State> successors = new ArrayList<>();
        ArrayList<State> succ;

        while (!stateList.isEmpty()) {
            // 初始化一个子孙stateList
            successors.clear();
            for (State state : stateList) {
                if (state.equals(stateInit)) { // 新论文里面没有判断这一步离谱，并且去掉后效果更好
                    succ = expandA(state, w * w);
                } else {
                    succ = expandA(state, w);
                }
                successors.addAll(succ);
            }
            stateList.clear();
            if (!successors.isEmpty()) {
                for (State state : successors) {
                    state.greedyScore = greedyA(state.cloneObj(), bestState, state);
                }
                // 选出前minL个greedyScore最大的块
                // 删除相似状态(目前没看出来有什么区别)
                successors = removeSimilarStates(successors);

                int minL = Math.min(successors.size(), w);
                // 简单选择排序选出最大的minL个块,放在块表前面
                for (int i = 0; i < minL; i++) {
                    int maxIndex = i;
                    for (int j = i + 1; j < successors.size(); j++) {
                        if (successors.get(maxIndex).greedyScore < successors.get(j).greedyScore) {
                            maxIndex = j;
                        }
                    }
                    // 保留最大的
                    stateList.add(successors.get(maxIndex));
                    // 交换
                    State stateTemp = successors.get(i);
                    successors.set(i, successors.get(maxIndex));
                    successors.set(maxIndex, stateTemp);
                }
            }
        }
    }

    /**
     * @Author yajiewen
     * @Date 2022-05-10 13-06-01
     * @Description greedy 返回装填体积
     */
    /**
     * @Author yajiewen
     * @Date 2023-02-16 13-28-45
     * @Description 优化代码
     */
    public static double greedyA(State state, State[]bestState, State oriState){
        while (!state.spaceArrayList.isEmpty()) {
            int selectedSpaceIndex = SpaceHelperA.selectSpace(state.spaceArrayList);
            ArrayList<Block> viableBlockList = BlockHelperA.searchViableBlockWithNumLimitByVH(state.spaceArrayList.get(selectedSpaceIndex), state, 1);
            if (!viableBlockList.isEmpty()) {
                State.renewState(state, viableBlockList.get(0), selectedSpaceIndex);
            } else {
                state.spaceArrayList.remove(selectedSpaceIndex);
            }
        }

        // 获取装填高度
        state.packHigh = state.highOfPacking();
        // 更新bestState
        if (bestState[0] == null) {
            bestState[0] = state;
        } else {
            if (bestState[0].scheme.totalVolum < state.scheme.totalVolum) {
                bestState[0] = state;
            }
        }
        oriState.finalavailBox = new int[oriState.availBox.length];
        System.arraycopy(state.availBox, 0, oriState.finalavailBox, 0, state.availBox.length);
        return state.scheme.totalVolum;
    }

    /**
     * @Author yajiewen
     * @Date 2022-05-11 11-48-22
     * @Description 删除相似状态
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-03 22-02-50
     * @Description 修改使得代码更加易读 神奇的是修改后br1 64 问题从0.9528 装填率变为
     */
    public static ArrayList<State> removeSimilarStates (ArrayList < State > stateList) {
        ArrayList<State> notSimilarStateList = new ArrayList<>();
        notSimilarStateList.add(stateList.get(0));
        boolean isSimilar = false;

        for (int i = 1; i < stateList.size(); i++) {
            isSimilar = false;
            // 拿出一个状态
            State stateA = stateList.get(i);
            for (int j = 0; j < notSimilarStateList.size(); j++) {
                // 拿出一个状态
                State stateB = notSimilarStateList.get(j);
                // 最终状态相似,则把当前装载体积小的换入notSimilarStateList
                if (Arrays.equals(stateA.finalavailBox, stateB.finalavailBox)) {
                    if (stateB.scheme.totalVolum > stateA.scheme.totalVolum) {
                        notSimilarStateList.set(j, stateA);
                    }
                    isSimilar = true;
                    break;
                }
            }
            if (!isSimilar) {
                notSimilarStateList.add(stateA);
            }
        }
        return notSimilarStateList;
    }
    /**
     * @Author yajiewen
     * @Date 2022-05-10 12-44-52
     * @Description expand 扩展节点算法
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-23 19-50-28
     * @Description 全新的expand函数，当搜索不到块的时候应该把这个空间删除，在选一个搜索，而不是返回空的后继，这样会导致有的状态没法往下搜索
     */
    public static ArrayList<State> expandA(State state, int w){
        ArrayList<Block> viableBlockList = new ArrayList<>();
        int selectedSpaceIndex = 0;
        // 当没找到块，并且还有剩余空间就继续找块
        while (viableBlockList.isEmpty() && !state.spaceArrayList.isEmpty()) {
            // 选出一个空间
            selectedSpaceIndex = SpaceHelperA.selectSpace(state.spaceArrayList);
            // 找块
            viableBlockList = BlockHelperA.searchViableBlockWithNumLimitByVH(state.spaceArrayList.get(selectedSpaceIndex), state, w);
            // 没找到删除空间
            if (viableBlockList.isEmpty()) {
                state.spaceArrayList.remove(selectedSpaceIndex);
            } else {
                break; //break 可省略
            }
        }

        ArrayList<State> succ = new ArrayList<>();
        for (Block block : viableBlockList) {
            State newState = State.getNewState(state, block, selectedSpaceIndex);
            succ.add(newState);
        }
        return succ;
    }
}
