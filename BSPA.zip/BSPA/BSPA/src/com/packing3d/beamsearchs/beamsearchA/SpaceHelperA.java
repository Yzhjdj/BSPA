package com.packing3d.beamsearchs.beamsearchA;

import com.packing3d.datastructure.space.Space;

import java.util.ArrayList;

public class SpaceHelperA {

    /**
     * @author yajiewen
     * @date 2024/09/05 21:59
     * @description 新的空间选择算法更具ançhantan距离选择空间
     */
    public static int selectSpace(ArrayList<Space> spaceArrayList){
        // 根据Manhantan anchor distance 选择空间 返回被选中空间的下标
        int minIndex = 0;
        for (int i = 0; i < spaceArrayList.size(); i++) {
            minIndex = i;
            for (int j = i; j < spaceArrayList.size(); j++){
                if(spaceArrayList.get(j).anchorDistance < spaceArrayList.get(minIndex).anchorDistance){
                    minIndex = j;
                }
            }
            // 交换
            Space temp = spaceArrayList.get(i);
            spaceArrayList.set(i, spaceArrayList.get(minIndex));
            spaceArrayList.set(minIndex, temp);
        }
        return 0;
    }
}
