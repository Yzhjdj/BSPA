package com.packing3d.beamsearchs.beamsearchB;
import com.packing3d.application.InitHelper;
import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.space.Space;
import com.packing3d.datastructure.state.State;
import java.util.ArrayList;

public class BlockHelperB {

    /**
     * @Author yajiewen
     * @Date 2022-10-22 09-51-36
     * @Description 更新，使得更快
     * 返回能放入空间的块的列表
     */
    public static ArrayList<Block> searchViableBlock(Space space, ArrayList<Block> blockList){
        ArrayList<Block> viableBlockList = new ArrayList<>();
        for (Block block : blockList) {
            if(block.blockLenght <= space.spaceLength &&
                    block.blockWidth <= space.spaceWidth){
                viableBlockList.add(block);
            }
        }
        return viableBlockList;
    }


    /**
     * @Author yajiewen
     * @Date 2022-10-22 09-49-39
     * @Description 优化fbr，因为放不进去的块不需要计算fbr
     */
    public static ArrayList<Block> searchViableBlockWithNumLimitByVH(Space space, State state, int number){
        ArrayList<Block> viableBlockList = searchViableBlock(space, state.blockList);
        if(!viableBlockList.isEmpty()){
            for (Block block : viableBlockList) {
                block.fbrScore = vhScore(InitHelper.a, InitHelper.b,  block, space, state);
            }

            ArrayList<Block> returnList = new ArrayList<>();
            int minLen = Math.min(number, viableBlockList.size());
            // 简单选择排序选出最大的minL个块,放在块表前面
            for(int i = 0; i < minLen; i++){
                int maxIndex = i;
                for(int j = i + 1; j < viableBlockList.size(); j++){
                    if(viableBlockList.get(maxIndex).fbrScore < viableBlockList.get(j).fbrScore){
                        maxIndex = j;
                    }
                }
                returnList.add(viableBlockList.get(maxIndex));
                // 交换
                Block blockTemp = viableBlockList.get(i);
                viableBlockList.set(i, viableBlockList.get(maxIndex));
                viableBlockList.set(maxIndex,blockTemp);
            }
            return returnList;
        }else{
            return viableBlockList;
        }
    }

    /**
     * @Author yajiewen
     * @Date 2022-11-05 13-03-05
     * @Description 求容器中与块A几乎相接触的块
     */
    /**
     * @Author yajiewen
     * @Date 2023-02-16 12-54-36
     * @Description 优化
     */

    /**
     * @Author yajiewen
     * @Date 2022-11-05 15-08-20
     * @Description 判断块，A与B 是否几乎接触, 也就是三个方向都要有交集
     */
    /**
     * @Author yajiewen
     * @Date 2022-11-06 00-00-04
     * @Description 修复 加p 的时候 范围两端都要加 加了以后效果直接起飞 效果直接干到95牛逼啦
     * 原文只在一边加
     */
    /**
     * @Author yajiewen
     * @Date 2023-02-16 12-54-44
     * @Description 优化
     */

    /**
     * @Author yajiewen
     * @Date 2022-11-05 13-18-51
     * @Description 计算块与容器接触的面积（几乎相接触的面积）
     */
    /**
     * @Author yajiewen
     * @Date 2022-11-05 23-51-21
     * @Description 优化减少重复计算
     */
    /**
     * @Author yajiewen
     * @Date 2022-11-05 13-45-34
     * @Description 求VCS分数
     */
    public static double vhScore(double a, double b, Block block, Space space, State state){
        // 计算剩余物品的平均高度
        double totalHigh = 0,boxNum = 0,leftNum = 0;
        for (int i = 0; i < state.availBox.length; i++) {
            // 计算类型i的箱子的剩余数目
            leftNum = state.availBox[i] - block.neededBoxNumOfEachType[i];
            if (leftNum > 0) {
                totalHigh += leftNum * state.problem.boxList.get(i).boxWidth;
                boxNum += leftNum;
            }
        }
        double avhigh = totalHigh / boxNum;
        return a * (block.blockVolum / space.spaceVolum) + b / avhigh;
    }

    /**
     * @Author yajiewen
     * @Date 2023-02-16 14-19-20
     * @Description fbr 分数
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-19 18-16-49
     * @Description 判断一个箱子能不能被放入空间
     */
}
