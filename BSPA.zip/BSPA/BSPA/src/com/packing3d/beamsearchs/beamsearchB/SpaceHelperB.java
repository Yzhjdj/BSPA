package com.packing3d.beamsearchs.beamsearchB;

import com.packing3d.datastructure.space.Space;

import java.util.ArrayList;

public class SpaceHelperB {
    /**
     * @Author yajiewen
     * @Date 2022-10-14 15-55-54
     * @Description
     * 修改：// 根据Manhantan anchor distance 选择空间 返回被选中空间的下标
     * 论文添加了三层A new iterative-doubling Greedy–Lookahead algorithm for the single
     * container loading problem
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-17 22-58-56
     * @Description
     * 优化从if里面提出体积德计算到if外面,把变量定义提出for之外
     */
    public static int selectSpace(ArrayList<Space> spaceArrayList){
        // 根据Manhantan anchor distance 选择空间 返回被选中空间的下标
        int minIndex = 0;
        for (int i = 0; i < spaceArrayList.size(); i++) {
            minIndex = i;
            for (int j = i; j < spaceArrayList.size(); j++){
                if(spaceArrayList.get(j).anchorDistance < spaceArrayList.get(minIndex).anchorDistance){
                    minIndex = j;
                }
            }
            // 交换
            Space temp = spaceArrayList.get(i);
            spaceArrayList.set(i, spaceArrayList.get(minIndex));
            spaceArrayList.set(minIndex, temp);
        }
        return 0;
    }
}
