package com.packing3d.beamsearchs.beamsearchC;
import com.packing3d.application.InitHelper;
import com.packing3d.datastructure.state.State;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author yajiewen
 * @date 2024/7/17
 */

public class BeamSearchC {

    public static Fastate run(State state){

        //生成初始状态
        Fastate iniFaState = Fastate.getInitFastate(state);
        Fastate []bestFaState = new Fastate[1];
        int up = iniFaState.fablockArrayList.size();
        int w = 1;
        int upW = Math.min(2,up);
        while (w <= up) {
            beamSearchC(w, bestFaState, iniFaState);
            w = (int) Math.ceil(Math.sqrt(2) * w);
        }
        return bestFaState[0];
    }

    public static void beamSearchC(int w, Fastate[] bestFaState, Fastate stateInit){
        // 定义一个state list
        ArrayList<Fastate> stateList = new ArrayList<>();
        stateList.add(stateInit);

        ArrayList<Fastate> successors = new ArrayList<>();
        ArrayList<Fastate> succ;

        while (!stateList.isEmpty()) {
            // 初始化一个子孙stateList
            successors.clear();
            for (Fastate state : stateList) {
                if (state.equals(stateInit)) { // 新论文里面没有判断这一步离谱，并且去掉后效果更好
                    succ = expandC(state, w * w);
                } else {
                    succ = expandC(state, w);
                }
                successors.addAll(succ);
            }
            stateList.clear();
            if (!successors.isEmpty()) {
                for (Fastate state : successors) {
                    state.greedyScore = greedyC(state.cloneObj(), bestFaState);
                }

                int minL = Math.min(successors.size(), w);
                // 简单选择排序选出最终高度最小的的minL个块,放在块表前面  冒泡排序
                for (int i = 0; i < minL; i++) {
                    int minIndex = i;
                    for (int j = i + 1; j < successors.size(); j++) {
                        if (successors.get(minIndex).greedyScore > successors.get(j).greedyScore) {
                            minIndex = j;
                        }
                    }
                    // 保留高度最低的
                    stateList.add(successors.get(minIndex));
                    // 交换
                    Fastate stateTemp = successors.get(i);
                    successors.set(i, successors.get(minIndex));
                    successors.set(minIndex, stateTemp);
                }
            }
        }
    }

    public static double greedyC(Fastate fastate, Fastate[] bestFaState){
        while(!fastate.faspaceArrayList.isEmpty() || !fastate.fablockArrayList.isEmpty()){
            if(fastate.faspaceArrayList.isEmpty() && !fastate.fablockArrayList.isEmpty()){ // 没有空间了 在顶部生成一个新空间
                fastate.getHightOfPack();
                double y = fastate.highPack;
                fastate.faspaceArrayList.add(new Faspace(0,y,fastate.problem.containnerLength));
            }
            //选择一个空间
            int faSpaceIndex = faSpaceSelecter(fastate);
            // 选择一个块
            ArrayList<Fablock> fablockList = fablockSelecter(fastate, fastate.faspaceArrayList.get(faSpaceIndex),1);
            if(!fablockList.isEmpty()){
                // 装入块更新状态
                Fablock fablock = fablockList.get(0);
                fastate.renewFastate(fablock,faSpaceIndex);
            }else{
                fastate.faspaceArrayList.remove(faSpaceIndex);
            }
        }

        // 获取最终装填高度
        fastate.getHightOfPack();
//        fastate.fascheme.FaschemeDetect(fastate.fascheme);
        // 更新bestState 保留高度最小的
        if (bestFaState[0] == null) {
            bestFaState[0] = fastate;
        } else {
            if (bestFaState[0].highPack > fastate.highPack) {
                bestFaState[0] = fastate;
            }
        }
        return fastate.highPack;
    }

    /**
     * @Author yajiewen
     * @Date 2022-05-10 12-44-52
     * @Description expand 扩展节点算法
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-23 19-50-28
     * @Description 全新的expand函数，当搜索不到块的时候应该把这个空间删除，在选一个搜索，而不是返回空的后继，这样会导致有的状态没法往下搜索
     */
    /**
     *
     * @author yajiewen
     * @date 2024/7/17
     * 修改为Fastate
     */


    public static ArrayList<Fastate> expandC(Fastate fastate, int w){
        ArrayList<Fablock> viableBlockList = new ArrayList<>();
        int selectedSpaceIndex = 0;
        // 当没找到块，并且还有剩余空间就继续找块
        while (viableBlockList.isEmpty() && !fastate.faspaceArrayList.isEmpty()) {
            // 选出一个空间
            selectedSpaceIndex = faSpaceSelecter(fastate);
            // 找块
            viableBlockList = fablockSelecter(fastate,fastate.faspaceArrayList.get(selectedSpaceIndex),w);
            // 没找到删除空间
            if (viableBlockList.isEmpty()) {
                fastate.faspaceArrayList.remove(selectedSpaceIndex);
            } else {
                break; //break 可省略
            }
        }

        ArrayList<Fastate> succ = new ArrayList<>();
        for (Fablock block : viableBlockList) {
            Fastate newState = Fastate.getNewFaState(fastate, block, selectedSpaceIndex);
            succ.add(newState);
        }
        return succ;
    }

    // 空间选择方法
    public static int faSpaceSelecter(Fastate fastate){
        // 先找出位置最低的空间
        ArrayList<Faspace> lowList = new ArrayList<>();
        double miny = fastate.faspaceArrayList.get(0).y;
        for (Faspace faspace : fastate.faspaceArrayList) {
            if(miny > faspace.y){
                miny = faspace.y;
            }
        }

        for (Faspace faspace1 : fastate.faspaceArrayList) {
            if(faspace1.y == miny){
                lowList.add(faspace1);
            }
        }
        // 在位置最低的空间里面找出位置最左边的空间
        int minxIndex = 0;
        for (int i = 1; i < lowList.size(); i++) {
            if(lowList.get(i).x < lowList.get(minxIndex).x){
                minxIndex = i;
            }
        }
        return minxIndex;
    }

    // 块选择方法
    public static ArrayList<Fablock> fablockSelecter(Fastate fastate, Faspace faspace,int w){
        // 找出所有能放入空间中的块
        ArrayList<Fablock> feasibleBlocks = new ArrayList<>();
        ArrayList<Fablock> returnList = new ArrayList<>();
        for (Fablock fablock : fastate.fablockArrayList) {
            if(fablock.length <= faspace.length){
                feasibleBlocks.add(fablock);
            }
        }

        if (feasibleBlocks.isEmpty()){
            return returnList;
        }
        // 找出feasibleblocks中高度最高的w个块
        blockSortDecrease(feasibleBlocks);
        int minNum = Math.min(w,feasibleBlocks.size());
        for (int i = 0; i < minNum; i++) {
            returnList.add(feasibleBlocks.get(i));
        }
        return returnList;
    }

    public static void blockSortDecrease(ArrayList<Fablock> blockList){
        blockList.sort(new Comparator<Fablock>() {
            @Override
            public int compare(Fablock o1, Fablock o2) {
                if (o2.width < o1.width) {
                    return -1;
                } else {
                    if (o2.width > o1.width) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            }
        });
    }
}
