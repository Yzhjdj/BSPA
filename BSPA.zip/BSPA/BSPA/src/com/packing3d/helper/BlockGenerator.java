package com.packing3d.helper;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Box;
import com.packing3d.datastructure.problem.Problem;

import java.util.ArrayList;

/**
 * @Author yajiewen
 * @Date 2022-10-21 09-44-51
 * @Description 为了代码可读 把之前BlockHelp 里面的块生成方法分类放到这个类里面
*/
public class BlockGenerator {

    
    /**
     * @author yajiewen
     * @date 2024/08/31 21:01
     * @description  简单快生成算法
     */
    
    public static ArrayList<Block> simpleBlocks(Problem problem) {
        ArrayList<Block> blocks = new ArrayList<>();

        for (int i = 0; i < problem.boxList.size();i++) {
            Box box = problem.boxList.get(i);
            int boxNum = box.boxNumber;
            for (int x = 1; x <= boxNum; x++) {
                for (int y = 1; y <= boxNum / x; y++) {
                    int []neededBoxNumOfEachType = new int[problem.typeNumberOfBox];
                    neededBoxNumOfEachType[i] = x * y;
                    double boxVolum = box.boxArea * x * y;
                    if(box.boxLength * x <= problem.containnerLength && box.boxWidth * y <= problem.containnerWidth){
                        blocks.add(new Block(problem.typeNumberOfBox,box.boxLength * x,box.boxWidth * y, boxVolum, neededBoxNumOfEachType));
                    }
                }
            }
        }
        return blocks;
    }

    public static ArrayList<Block> complexBlocks(Problem problem, int MaxBlocks, double MinFillRate){
        long start = System.currentTimeMillis();
        ArrayList<Block> blockList = simpleBlocks(problem);
        // 开始进行块拼接
        ArrayList<Block> pList = new ArrayList<>(blockList);
        ArrayList<Block> newBlockList = new ArrayList<>();

        boolean isBreak = false;
        while(blockList.size() < MaxBlocks){
            newBlockList.clear();
            for (Block block1 : pList) {
                for (Block block2 : blockList) {
                    ArrayList<Block> combinedBlocks;
                    combinedBlocks = CombineBlocks(block1,block2,MinFillRate,problem);
                    if(!combinedBlocks.isEmpty()){
                        newBlockList.addAll(combinedBlocks);
                    }
                    if(newBlockList.size() + blockList.size() >= MaxBlocks){
                        isBreak = true;
                        break;
                    }
                }
                if(isBreak){
                    break;
                }
            }
            if(newBlockList.isEmpty()){
                break;
            }
            for (Block block : newBlockList) {
                if(blockList.size() < MaxBlocks){
                    blockList.add(block);
                }
            }
            pList = new ArrayList<>(newBlockList);
        }

        System.out.println("Guillotine Blocks块生成完毕:" + blockList.size() +"块" +"   生成时间" + (System.currentTimeMillis() - start) + "ms");
        return blockList;
    }

    /**
     * @Author yajiewen
     * @Date 2023-02-21 12-03-43
     * @Description 添加旋转块
    */
    public static void addRotatedBlocks(ArrayList<Block> blockList, Problem problem){
        ArrayList<Block> rotatedBlocks = new ArrayList<>();
        for (Block block : blockList) {
            // 若旋转后可以放入容器
            if(block.boxNum != 1 && block.blockLenght <= problem.containnerWidth && block.blockWidth <= problem.containnerLength){
                rotatedBlocks.add(block.getRotatedBlock());
            }
        }
        blockList.addAll(rotatedBlocks);
    }

    /**
     * @Author yajiewen
     * @Date 2023-02-22 20-41-13
     * @Description 获取旋转后的块表,用于兄弟BSGI
    */
    public static ArrayList<Block> getRotatedBlockList(ArrayList<Block> blockList,Problem problem){
        ArrayList<Block> rotatedBlocks = new ArrayList<>();
        for (Block block : blockList) {
            if(block.boxNum == 1){
                rotatedBlocks.add(block.cloneOne());
            }else{
                if(block.blockLenght <= problem.containnerWidth && block.blockWidth <= problem.containnerLength){
                    rotatedBlocks.add(block.getRotatedBlock());
                }
            }
        }
        return rotatedBlocks;
    }



    /**
     *
     * @author yajiewen
     * @date 2024/5/6
     * 生成 单个块解决丢失问题
     */
    public static ArrayList<Block> singelFixBlocks(Problem problem){
        ArrayList<Block> blockList = new ArrayList<>(10000);
        // 用单个箱子生成6个方项的块
        for (int p = 0; p < problem.typeNumberOfBox; p++) {
            Box box = problem.boxList.get(p);
            double boxLength = box.boxLength;
            double boxWidth = box.boxWidth;

            int[] neededBoxNumOfEachType = new int[problem.typeNumberOfBox];
            neededBoxNumOfEachType[p] = 1;
            Block block = new Block(problem.typeNumberOfBox, boxLength, boxWidth, boxLength * boxWidth , neededBoxNumOfEachType);
            blockList.add(block);

        }
        return blockList;
    }


    /**
     *
     * @author yajiewen
     * @date 2024/7/14
     */

    public static ArrayList<Block> CombineBlocks(Block block1, Block block2, double minFillRate, Problem problem){
        // x方向拼接的长和宽和面积
        double xLength = block1.blockLenght + block2.blockLenght;
        double xWidth = Math.max(block1.blockWidth,block2.blockWidth);
        double xArea = xLength * xWidth;
        // y方向拼接的长和宽和面积
        double yLength = Math.max(block1.blockLenght,block2.blockLenght);
        double yWidth = block1.blockWidth + block2.blockWidth;
        double yArea = yLength * yWidth;


        // 条件4
        int[] blockNeededBoxNumOfEachType = new int[block1.typeNumberOfBox];
        for(int i = 0; i < block1.typeNumberOfBox; i++){
            blockNeededBoxNumOfEachType[i] = block1.neededBoxNumOfEachType[i] + block2.neededBoxNumOfEachType[i];
        }

        ArrayList<Block> blockList = new ArrayList<>();
        if(canCombine(xLength,xWidth,xArea,minFillRate,problem,block1,block2)){
            blockList.add(new Block(block1.typeNumberOfBox,xLength,xWidth,
                    block1.boxVolum + block2.boxVolum,blockNeededBoxNumOfEachType));
        }

        if(canCombine(yLength,yWidth,yArea,minFillRate,problem,block1,block2)){
            blockList.add(new Block(block1.typeNumberOfBox,yLength,yWidth,
                    block1.boxVolum + block2.boxVolum,blockNeededBoxNumOfEachType));
        }
        return blockList;
    }


    /**
     * @author yajiewen
     * @date 2024/08/31 21:21
     * @description 块拼接条件方法
     */
    public static boolean canCombine(double length, double width, double area,double minFillRate,Problem problem, Block block1, Block block2){
        // 条件1 要能放入容器
        if(length > problem.containnerLength || width > problem.containnerWidth){
            return false;
        }
        // 条件2 要满足最小填充率
        if((block1.boxVolum + block2.boxVolum) / area < minFillRate){
            return false;
        }
        // 条件3 拼接后的箱子数目不超过可用箱子数量
        for(int i = 0; i < block1.typeNumberOfBox; i++){
            if(block1.neededBoxNumOfEachType[i] + block2.neededBoxNumOfEachType[i] > problem.boxList.get(i).boxNumber){
                return false;
            }
        }
        return true;
    }
}
