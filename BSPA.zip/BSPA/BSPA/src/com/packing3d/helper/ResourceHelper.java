package com.packing3d.helper;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.scheme.Put;
import com.packing3d.datastructure.space.Space;
import com.packing3d.datastructure.state.State;

import java.util.ArrayList;

/**
 * @Author yajiewen
 * @Date 2022-04-25 12-06-56
 * @Description 优化代码
 * 更新剩余空间和剩余箱子数目
 */
public class ResourceHelper {
    /**
     * @Author yajiewen
     * @Date 2022-10-21 14-02-43
     * @Description 优化:将删除被选中空间操作移入renewResource
     */
    /**
     * @Author yajiewen
     * @Date 2022-11-05 10-41-27
     * @Description 优化把scheme的更新也放入里面
     */
    // 资源(状态)更新(传入的spaceArrayList 是顶部空间去除后的, space 是被去除的放置空间, block是放置快,)
    public static void renewResource(State state, int selectedSpaceIndex, Block block){
        // 更新scheme(首先需要更新块坐标)
        Space space = state.spaceArrayList.get(selectedSpaceIndex);
        // 把块放在空间的anchor点,根据空间anchor点坐标更新块的八点坐标
        block.initCoordinateAndRangeByAnchorCorner(space);
        state.scheme.addPut(new Put(block,space));

        // 更新箱子数目
        renewAvailBoxNum(block, state.availBox);
        // 更新剩余空间
        renewSpaceListByMinus(block,selectedSpaceIndex,state.spaceArrayList,state.problem);
        // 更新块表
        renewBlockList(state);
    }

    /**
     * @Author yajiewen
     * @Date 2022-06-07 10-36-15
     * @Description 剩余更新箱子数目
     */
    public static void renewAvailBoxNum(Block block, int[] availNum){
        for (int i = 0; i < availNum.length; i++) {
            availNum[i] -= block.neededBoxNumOfEachType[i];
        }
    }


    /**
     * @Author yajiewen
     * @Date 2022-10-22 21-14-11
     * @Description 新的剩余空间列表更新(非完全支撑)
     */
    public static void renewSpaceListByMinus(Block block, int selectedSpaceIndex, ArrayList<Space> spaceArrayList, Problem problem){
        // 从空间列表中删除被选中的空间
        Space space = spaceArrayList.remove(selectedSpaceIndex);
        // 根据八点坐标得到当前被放置空间的剩余空间
        ArrayList<Space> newSpaceList = minus(space,block,problem);

        // 删除不可以放入任何空间的空间， 减少后面coverSpace 计算量  得到有效空间
        ArrayList<Space> spaceArrayList1 = new ArrayList<>();
        for (Space space0 : spaceArrayList) {
            if(space0.spaceVolum >= problem.minItermArea){
                spaceArrayList1.add(space0);
            }
        }

        // 先找出所有与块交叠的空间
        ArrayList<Space> intersectingSpacList = new ArrayList<>();
        for (Space space1 : spaceArrayList1) {
            if(isIntersecting(space1,block)){
                intersectingSpacList.add(space1);
            }
        }
        // 有效空间的列表删除 交叠的空间
        for (Space space2 : intersectingSpacList) {
            spaceArrayList1.remove(space2);
        }
        // 更新 其余交叠空间
        ArrayList<Space> coveredSpaceList = new ArrayList<>();
        for (Space space3 : intersectingSpacList) {
            coveredSpaceList.addAll(minus(space3, block, problem));
        }

        // 把有效的cover空间加入
        for (Space space4 : coveredSpaceList) {
            if(space4.spaceVolum >= problem.minItermArea){
                newSpaceList.add(space4);
            }
        }
        spaceArrayList1.addAll(newSpaceList);
        deleteIncludingSpace(spaceArrayList1);
        spaceArrayList.clear();
        spaceArrayList.addAll(spaceArrayList1);
    }

    /**
     * @Author yajiewen
     * @Date 2022-10-22 20-20-11
     * @Description space - block
     */
    /**
     * @Author yajiewen
     * @Date 2023-05-10 20-47-02
     * @Description 用于二维交叠空间的更新
    */
    public static ArrayList<Space> minus(Space space, Block block, Problem problem){
        ArrayList<Space> outcomeSpaceList = new ArrayList<>();
        // 前后左右四个空间
        if(block.eightCoordinate[2][0] < space.eightCoordinate[2][0]){
            double minX = block.eightCoordinate[2][0];
            double minY = space.eightCoordinate[0][1];
            double maxX = space.eightCoordinate[2][0];
            double maxY = space.eightCoordinate[2][1];
            Space space1 = new Space(minX, minY, maxX - minX, maxY - minY, problem);
            outcomeSpaceList.add(space1);
        }

        if(block.eightCoordinate[2][1] < space.eightCoordinate[2][1]){
            double minX = space.eightCoordinate[0][0];
            double minY = block.eightCoordinate[2][1];
            double maxX = space.eightCoordinate[2][0];
            double maxY = space.eightCoordinate[2][1];
            Space space1 = new Space(minX, minY, maxX - minX, maxY - minY, problem);
            outcomeSpaceList.add(space1);
        }

        if(space.eightCoordinate[0][0] < block.eightCoordinate[0][0]){
            double minX = space.eightCoordinate[0][0];
            double minY = space.eightCoordinate[0][1];
            double maxX = block.eightCoordinate[0][0];
            double maxY = space.eightCoordinate[2][1];
            Space space1 = new Space(minX, minY,maxX - minX, maxY - minY, problem);
            outcomeSpaceList.add(space1);
        }

        if(space.eightCoordinate[0][1] < block.eightCoordinate[0][1]){
            double minX = space.eightCoordinate[0][0];
            double minY = space.eightCoordinate[0][1];
            double maxX = space.eightCoordinate[2][0];
            double maxY = block.eightCoordinate[0][1];
            Space space1 = new Space(minX, minY,maxX - minX, maxY - minY, problem);
            outcomeSpaceList.add(space1);
        }


        return outcomeSpaceList;
    }

    /**
     * @Author yajiewen
     * @Date 2022-10-22 20-22-36
     * @Description 判断块和空间 是否相交
     */
    public static boolean isIntersecting(Space space, Block block){
        // 先判断是否有交集(物体和空间相交,三个方向都必须有交集)
        if(space.xRange[1] <= block.xRange[0] || block.xRange[1] <= space.xRange[0]){
            return false;
        }
        if(space.yRange[1] <= block.yRange[0] || block.yRange[1] <= space.yRange[0]){
            return false;
        }

        return true;
    }

    /**
     * @Author yajiewen
     * @Date 2022-10-21 01-10-09
     * @Description 判断空间是否包含在空间列表中某一空间内
     */
    public static boolean isSpaceContainToOneOfTheSpaceList(ArrayList<Space> spaceArrayList, Space space){
        for (Space space1 : spaceArrayList) {
            if(isInSpace(space, space1)){
                return true;
            }
        }
        return false;
    }

    /**
     * @Author yajiewen
     * @Date 2022-06-07 10-44-52
     * @Description 若一个空间A包含在另一个空间B中,删除A
     * 这个方法正确
     */
    public static void deleteIncludingSpace(ArrayList<Space> spaceArrayList){
        // 先找出包含在其他空间中的空间
        ArrayList<Space> includeSpaces = new ArrayList<>();
        for (Space space : spaceArrayList) {
            for (Space space1 : spaceArrayList) {
                if(space != space1 && isInSpace(space,space1) && !includeSpaces.contains(space)) //不相同且space 在space1里面
                {includeSpaces.add(space);}
            }
        }

        if(!includeSpaces.isEmpty()){
            ArrayList<Space> spaceList = new ArrayList<>();
            for (Space space2 : spaceArrayList) {
                if(!includeSpaces.contains(space2)){
                    spaceList.add(space2);
                }
            }
            spaceArrayList.clear();
            spaceArrayList.addAll(spaceList);
        }
    }


    /**
     * @Author yajiewen
     * @Date 2022-06-07 10-41-46
     * @Description 检测空间是否有包含
     */
    public static void detectSpatialPhaseInclusions(ArrayList<Space> spaceArrayList){
        //检查以下是否有空间包含
        for (int i = 0; i < spaceArrayList.size(); i++) {
            Space spaceA = spaceArrayList.get(i);
            for (Space spaceB : spaceArrayList) {
                if (!spaceA.equals(spaceB) && inStateCode(spaceA, spaceB) != 0) {
                    System.out.println("发生空间包含");
                    System.out.println(spaceA);
                    System.out.println(spaceB);
                }
            }
        }
    }

    /**
     * @Author yajiewen
     * @Date 2022-06-07 11-17-46
     * @Description 更新块表 (删除不满足剩余箱子数目的块)
     */
    public static void renewBlockList(State state){
        // 删除剩余箱子不可生成的块
        for (int i = state.blockList.size() -1; i >= 0; i--) {
            // 判断剩余箱子能否生成此块
            boolean isOk = true;
            Block block1 = state.blockList.get(i);

            for (int j = 0; j < state.availBox.length; j++) {
                if(block1.neededBoxNumOfEachType[j] > state.availBox[j]){
                    isOk  = false;
                    break;
                }
            }
            if(!isOk){
                state.blockList.remove(i);
            }
        }
    }



    /*A 在B 内返回1
     * B 在A 内返回2
     * 不相互属于返回0*/
    public static int inStateCode(Space spaceA, Space spaceB){
        if(isInSpace(spaceA,spaceB)){
            return 1;
        }
        if(isInSpace(spaceB,spaceA)){
            return 2;
        }
        return 0;
    }
    // 判断空间A 是否包含在空间B内
    public static boolean isInSpace(Space spaceA, Space spaceB){
        return spaceA.xRange[0] >= spaceB.xRange[0] && spaceA.xRange[1] <= spaceB.xRange[1] &&
                spaceA.yRange[0] >= spaceB.yRange[0] && spaceA.yRange[1] <= spaceB.yRange[1];
    }
}
