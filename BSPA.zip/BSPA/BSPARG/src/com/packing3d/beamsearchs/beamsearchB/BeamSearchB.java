package com.packing3d.beamsearchs.beamsearchB;

import com.packing3d.beamsearchs.beamsearchA.BlockHelperA;
import com.packing3d.beamsearchs.beamsearchA.SpaceHelperA;
import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.state.State;
import com.packing3d.beamsearchs.beamsearchC.Fastate;
import com.packing3d.beamsearchs.beamsearchC.BeamSearchC;
import com.packing3d.helper.BlockGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class BeamSearchB {

    public static State run(Problem problem,int timeLimit, double MinFillRate, boolean isRuoYiGou, State[] bestStates, double[] bestHighs, int finI ,Fastate[] bestFaStates ){

        ArrayList<Block> blockList = BlockGenerator.complexBlocks(problem,10000,MinFillRate); // 每个线程中的块表需要单独生成 否则多个线程中的块会被公用 而坐标出错
        // 生成初始状态
        State stateInit = new State(problem, blockList);
        System.out.println("BeamSearchB 初始状态生成完成，开始搜索，开始搜索");

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                int w = 1;
                while (true) {
                    beamSearchB(w, bestStates, bestHighs,finI,bestFaStates ,stateInit);
                    w = (int) Math.ceil(Math.sqrt(2) * w);
                }
            }
        });
        long start = System.currentTimeMillis();
        thread.start();
        try {
            TimeUnit.MILLISECONDS.sleep(timeLimit);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        thread.stop();
        System.out.println("运行时间:" + (System.currentTimeMillis() - start) + "ms");
        // 返回结果
        return bestStates[finI];
    }


    public static void beamSearchB(int w, State[] bestStates, double[] bestHighs, int finI, Fastate[] bestFaStates , State stateInit){
        // 定义一个state list
        ArrayList<State> stateList = new ArrayList<>();
        stateList.add(stateInit);

        ArrayList<State> successors = new ArrayList<>();
        ArrayList<State> succ;

        while (!stateList.isEmpty()) {
            // 初始化一个子孙stateList
            successors.clear();
            for (State state : stateList) {
                if (state.equals(stateInit)) { // 新论文里面没有判断这一步离谱，并且去掉后效果更好
                    succ = expandB(state, w * w);
                } else {
                    succ = expandB(state, w);
                }
                successors.addAll(succ);
            }
            stateList.clear();
            if (!successors.isEmpty()) {
                for (State state : successors) {
                    state.greedyScore = greedyB(state.cloneObj(),state, bestStates,bestHighs,bestFaStates,finI);
                }
                // 选出前minL个greedyScore最大的块
                // 删除相似状态(目前没看出来有什么区别)
                successors = removeSimilarStates(successors);

                int minL = Math.min(successors.size(), w);
                // 简单选择排序选出最大的minL个块,放在块表前面
                for (int i = 0; i < minL; i++) {
                    int maxIndex = i;
                    for (int j = i + 1; j < successors.size(); j++) {
                        if (successors.get(maxIndex).greedyScore < successors.get(j).greedyScore) {
                            maxIndex = j;
                        }
                    }
                    // 保留最大的
                    stateList.add(successors.get(maxIndex));
                    // 交换
                    State stateTemp = successors.get(i);
                    successors.set(i, successors.get(maxIndex));
                    successors.set(maxIndex, stateTemp);
                }
            }
        }
    }

    public static ArrayList<State> removeSimilarStates (ArrayList < State > stateList) {
        ArrayList<State> notSimilarStateList = new ArrayList<>();
        notSimilarStateList.add(stateList.get(0));
        boolean isSimilar = false;

        for (int i = 1; i < stateList.size(); i++) {
            isSimilar = false;
            // 拿出一个状态
            State stateA = stateList.get(i);
            for (int j = 0; j < notSimilarStateList.size(); j++) {
                // 拿出一个状态
                State stateB = notSimilarStateList.get(j);
                // 最终状态相似,则把当前装载体积小的换入notSimilarStateList
                if (Arrays.equals(stateA.finalavailBox, stateB.finalavailBox)) {
                    if (stateB.scheme.totalVolum > stateA.scheme.totalVolum) {
                        notSimilarStateList.set(j, stateA);
                    }
                    isSimilar = true;
                    break;
                }
            }
            if (!isSimilar) {
                notSimilarStateList.add(stateA);
            }
        }
        return notSimilarStateList;
    }

    public static double greedyB(State state, State oriState, State[] bestStates, double[] bestHighs, Fastate[] bestFaStates , int finI ){

        while (!state.spaceArrayList.isEmpty()) {
            int selectedSpaceIndex = SpaceHelperB.selectSpace(state.spaceArrayList);
            ArrayList<Block> viableBlockList = BlockHelperB.searchViableBlockWithNumLimitByVH(state.spaceArrayList.get(selectedSpaceIndex), state, 1);
            if (!viableBlockList.isEmpty()) {
                State.renewState(state, viableBlockList.get(0), selectedSpaceIndex);
            } else {
                state.spaceArrayList.remove(selectedSpaceIndex);
            }
        }
        // 获取装填高度
        state.packHigh = state.highOfPacking();
        double outPackHigh = 0;
        Fastate fastate = null;

        if(State.isAllPacked(state)){
            outPackHigh = state.packHigh;
        }else{
            fastate = BeamSearchC.run(state);
            state.fastate = fastate;
            double fastateHigh = fastate.highPack; // 获取快速装填高度
            outPackHigh = state.packHigh + fastateHigh;
        }
        // 更新bestState
        if (outPackHigh < bestHighs[finI]) {
            bestHighs[finI] = outPackHigh;
            bestStates[finI] = state;
            if(!State.isAllPacked(state)){
                bestFaStates[finI] = fastate;
            }
        }

        oriState.finalavailBox = new int[oriState.availBox.length];
        System.arraycopy(state.availBox, 0, oriState.finalavailBox, 0, state.availBox.length);
        return state.scheme.totalVolum;
    }
    public static ArrayList<State> expandB(State state, int w){
        ArrayList<Block> viableBlockList = new ArrayList<>();
        int selectedSpaceIndex = 0;
        // 当没找到块，并且还有剩余空间就继续找块
        while (viableBlockList.isEmpty() && !state.spaceArrayList.isEmpty()) {
            // 选出一个空间
            selectedSpaceIndex = SpaceHelperA.selectSpace(state.spaceArrayList);
            // 找块
            viableBlockList = BlockHelperA.searchViableBlockWithNumLimitByVH(state.spaceArrayList.get(selectedSpaceIndex), state, w);
            // 没找到删除空间
            if (viableBlockList.isEmpty()) {
                state.spaceArrayList.remove(selectedSpaceIndex);
            } else {
                break; //break 可省略
            }
        }

        ArrayList<State> succ = new ArrayList<>();
        for (Block block : viableBlockList) {
            State newState = State.getNewState(state, block, selectedSpaceIndex);
            succ.add(newState);
        }
        return succ;
    }
}
