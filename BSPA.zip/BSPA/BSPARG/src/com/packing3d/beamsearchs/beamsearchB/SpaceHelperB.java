package com.packing3d.beamsearchs.beamsearchB;

import com.packing3d.datastructure.space.Space;

import java.util.ArrayList;

public class SpaceHelperB {
    /**
     * @Author yajiewen
     * @Date 2022-10-14 15-55-54
     * @Description
     * 修改：// 根据Manhantan anchor distance 选择空间 返回被选中空间的下标
     * 论文添加了三层A new iterative-doubling Greedy–Lookahead algorithm for the single
     * container loading problem
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-17 22-58-56
     * @Description
     * 优化从if里面提出体积德计算到if外面,把变量定义提出for之外
     */
    public static int selectSpace(ArrayList<Space> spaceArrayList){
        // 先找出位置最低的空间
        ArrayList<Space> lowList = new ArrayList<>();
        double miny =  spaceArrayList.get(0).locationY;
        for (Space space :  spaceArrayList) {
            if(miny > space.locationY){
                miny = space.locationY;
            }
        }

        for (Space space1 : spaceArrayList) {
            if(space1.locationY == miny){
                lowList.add(space1);
            }
        }

        // 在位置最低的空间里面找出位置最左边的空间
        int minxIndex = 0;
        for (int i = 1; i < lowList.size(); i++) {
            if(lowList.get(i).locationX < lowList.get(minxIndex).locationX){
                minxIndex = i;
            }
        }
        return minxIndex;
    }
}
