package com.packing3d.beamsearchs.beamsearchC;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.space.Space;

public class Faput {

    public double minx;
    public double miny;
    public double maxx;
    public double maxy;
    public double volume;

    public Faput(Fablock fablock, Faspace faspace) {
        this.minx = faspace.x;
        this.miny = faspace.y;
        this.maxx = this.minx + fablock.length;
        this.maxy = this.miny + fablock.width;
        this.volume = fablock.volume;
    }

}
