package com.packing3d.beamsearchs.beamsearchC;

import com.packing3d.datastructure.scheme.Put;
import com.packing3d.datastructure.scheme.Scheme;

import java.util.ArrayList;

public class Fascheme {
    public ArrayList<Faput> faputList;
    public double totalVolume;

    public Fascheme() {
        this.faputList = new ArrayList<>();
        this.totalVolume = 0;
    }

    public void addFaput(Faput faput){
        faputList.add(faput);
        totalVolume += faput.volume;
    }

    // 克隆对象
    public Fascheme cloneObj(){
        Fascheme scheme = new Fascheme();
        scheme.totalVolume = this.totalVolume;
        for (Faput put : this.faputList) {
            scheme.faputList.add(put); // 不需要克隆put
        }
        return scheme;
    }


}
