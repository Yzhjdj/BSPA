package com.packing3d.beamsearchs.beamsearchC;

import com.packing3d.datastructure.problem.Box;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.state.State;

import java.util.ArrayList;
import java.util.Collections;

public class Fastate {
    public Fascheme fascheme;
    public ArrayList<Faspace> faspaceArrayList;
    public ArrayList<Fablock> fablockArrayList;
    double greedyScore = 0;
    public Problem problem;
    public double highPack = 0;
    public int[] avaBox;//剩余箱子

    public Fastate() {
        this.fascheme = new Fascheme();
        this.faspaceArrayList = new ArrayList<>();
        this.fablockArrayList = new ArrayList<>();
    }

    public static Fastate getInitFastate(State state){
        Fastate iniFaState = new Fastate();
        iniFaState.problem = state.problem;
        iniFaState.avaBox = new int[state.availBox.length];
        System.arraycopy(state.availBox, 0, iniFaState.avaBox, 0, state.availBox.length);

        // 获取空间
        iniFaState.faspaceArrayList.add(new Faspace(0,0,state.problem.containnerLength));
        // 获取剩余物品
        for (int i = 0; i < state.availBox.length; i++) {
            if(state.availBox[i] > 0){
                Box box = state.problem.boxList.get(i);
                int [] needboxNum = new int[state.availBox.length];
                needboxNum[i] = 1;

                iniFaState.fablockArrayList.add(new Fablock(0,0,box.boxLength, box.boxWidth, needboxNum));
                if(box.boxWidth <= iniFaState.problem.containnerLength)
                {
                    iniFaState.fablockArrayList.add(new Fablock(0,0,box.boxWidth, box.boxLength, needboxNum));
                }
            }
        }
        return iniFaState;
    }

    public void renewFastate(Fablock fablock, int faspaceIndex){
        this.fascheme.addFaput(new Faput(fablock,this.faspaceArrayList.get(faspaceIndex)));
        Faspace faspace = this.faspaceArrayList.remove(faspaceIndex);
        this.faspaceArrayList.addAll(Faspace.faMinus(faspace,fablock));
        //删除箱子
        for(int i = 0; i < this.avaBox.length; i++){
            this.avaBox[i] = this.avaBox[i] - fablock.needboxnum[i];
        }
        // 删除块
        for(int j = this.fablockArrayList.size() - 1; j >= 0; j--){
            Fablock fablock1 = this.fablockArrayList.get(j);
            boolean isOk = true;
            for(int i = 0; i < this.avaBox.length; i++){
                if(fablock1.needboxnum[i] > this.avaBox[i]){
                    isOk = false;
                    break;
                }
            }
            if(!isOk){
                this.fablockArrayList.remove(j);
            }
        }
    }

    // 获取新的状态(在复制的上面更新)
    public static Fastate getNewFaState(Fastate stateOld, Fablock block, int selectedSpaceIndex){
        Fastate newState = stateOld.cloneObj();
        // 更新资源相关
        newState.renewFastate(block,selectedSpaceIndex);
        return newState;
    }

    // 用于克隆state ,搜索阶段需要克隆
    public Fastate cloneObj(){
        Fastate fastate = new Fastate();
        // 复制空间栈内容
        fastate.faspaceArrayList.addAll(this.faspaceArrayList);
        // 复制块表内容
        fastate.fablockArrayList.addAll(this.fablockArrayList);
        fastate.fascheme = this.fascheme.cloneObj();
        fastate.greedyScore = this.greedyScore;
        fastate.highPack = this.highPack;
        fastate.problem = this.problem;
        int[] avaBoxnum = new int[this.avaBox.length];
        System.arraycopy(this.avaBox, 0, avaBoxnum, 0, this.avaBox.length);
        fastate.avaBox = avaBoxnum;
        return fastate;
    }

    // 获取装填高度
    public void getHightOfPack(){
        // 获取所有块的最高点y坐标
        ArrayList<Double> maxYs = new ArrayList<>();
        for (Faput faput : this.fascheme.faputList) {
            maxYs.add(faput.maxy);
        }
         this.highPack = Collections.max(maxYs);
    }

    // 判断是否还有剩余的箱子
    static public boolean isHasLeftBox(Fastate fastate){
        for (int avaBox : fastate.avaBox) {
            if(avaBox > 0){
                return true;
            }
        }
        return false;
    }
}
