package com.packing3d.datastructure.space;

import com.packing3d.datastructure.problem.Problem;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author yajiewen
 * @Date 2022-05-14 10-51-45
 * @Description 支持Manhanttan distance
*/
public class Space{
    public double locationX; // 空间左后下角的X坐标
    public double locationY; // 空间左后下角的Y坐标
    public double spaceLength; // 空间的长
    public double spaceWidth; // 空间的宽
    public double spaceVolum; // 空间体积

    // 定义一个二维数组来保存八点坐标
    public double[][] eightCoordinate;
    // 定义保存x范围的数组
    public double[] xRange;
    // 定义保存y范围的数组
    public double[] yRange;
    // 定义anchorDistance
    public double anchorDistance;
    // 定义anchor corner
    public int anchorCorner;

    // 使用0点坐标 和空间的长宽高 生成带 anchordistanse 和 corner 的空间
    public Space(double locationX, double locationY,  double spaceLength, double spaceWidth, Problem problem) {
        this.locationX = locationX;
        this.locationY = locationY;
        this.spaceLength = spaceLength;
        this.spaceWidth = spaceWidth;
        this.spaceVolum = spaceLength * spaceWidth;
        // 在构造函数里面分配空间
        // 坐标空间
        eightCoordinate = new double[4][2];
        // x范围空间
        xRange = new double[2];
        // y范围空间
        yRange = new double[2];

        // 获取8点坐标
        eightCoordinate[0][0] = locationX;
        eightCoordinate[0][1] = locationY;

        eightCoordinate[1][0] = eightCoordinate[0][0] + spaceLength;
        eightCoordinate[1][1] = eightCoordinate[0][1];

        eightCoordinate[2][0] = eightCoordinate[0][0] + spaceLength;
        eightCoordinate[2][1] = eightCoordinate[0][1] + spaceWidth;

        eightCoordinate[3][0] = eightCoordinate[0][0];
        eightCoordinate[3][1] = eightCoordinate[0][1] + spaceWidth;

        // 获取x,y,z 范围
        xRange[0] = eightCoordinate[0][0];
        xRange[1] = eightCoordinate[1][0];
        yRange[0] = eightCoordinate[0][1];
        yRange[1] = eightCoordinate[3][1];

        getManhanttanDistanceAndAnchorCorner(problem);

    }
    //通过rang生成空间
    public Space(double[] xRange, double[] yRange, Problem problem) {
        this.locationX = xRange[0];
        this.locationY = yRange[0];
        this.spaceLength =xRange[1] - xRange[0];
        this.spaceWidth = yRange[1] - yRange[0];
        this.spaceVolum = spaceLength * spaceWidth;
        // 在构造函数里面分配空间
        // 坐标空间
        eightCoordinate = new double[4][2];
        // x范围空间
        this.xRange = xRange;
        // y范围空间
        this.yRange = yRange;

        // 获取8点坐标
        eightCoordinate[0][0] = locationX;
        eightCoordinate[0][1] = locationY;

        eightCoordinate[1][0] = eightCoordinate[0][0] + spaceLength;
        eightCoordinate[1][1] = eightCoordinate[0][1];

        eightCoordinate[2][0] = eightCoordinate[0][0] + spaceLength;
        eightCoordinate[2][1] = eightCoordinate[0][1] + spaceWidth;

        eightCoordinate[3][0] = eightCoordinate[0][0];
        eightCoordinate[3][1] = eightCoordinate[0][1] + spaceWidth;

        getManhanttanDistanceAndAnchorCorner(problem);

    }

    // 通过八点坐标生成空间 生成呆 anchordistanse 和 corner 的空间2
    public Space(double[][] eightCoordinate,Problem problem){
        // 在构造函数里面分配空间
        // x范围空间
        xRange = new double[2];
        // y范围空间
        yRange = new double[2];
        this.locationX = eightCoordinate[0][0];
        this.locationY = eightCoordinate[0][1];

        this.spaceLength = eightCoordinate[1][0] - eightCoordinate[0][0];
        this.spaceWidth = eightCoordinate[3][1] - eightCoordinate[0][1];
        this.spaceVolum = this.spaceLength * this.spaceWidth;
        // 获取x,y,z 范围
        xRange[0] = eightCoordinate[0][0];
        xRange[1] = eightCoordinate[1][0];
        yRange[0] = eightCoordinate[0][1];
        yRange[1] = eightCoordinate[3][1];

        this.eightCoordinate = eightCoordinate;
        getManhanttanDistanceAndAnchorCorner(problem);

    }
    /**
     *
     * @author yajiewen
     * @date 2024/7/15
     * 永远放在最低处最左边
     * 永远放在最低处最左边
     */

    public void getManhanttanDistanceAndAnchorCorner(Problem problem){
        this.anchorCorner = 0;
    }

    // 判断通过八点坐标生成的空间的体积是否为0
    public boolean isZeroV(){
        if(spaceWidth == 0 || spaceLength == 0){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Space space = (Space) o;
        return Double.compare(space.locationX, locationX) == 0 && Double.compare(space.locationY, locationY) == 0  && Double.compare(space.spaceLength, spaceLength) == 0 && Double.compare(space.spaceWidth, spaceWidth) == 0 ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(locationX, locationY, spaceLength, spaceWidth);
    }

    @Override
    public String toString() {
        return "Space{" +
                "xRange=" + Arrays.toString(xRange) +
                ", yRange=" + Arrays.toString(yRange) +
                '}';
    }
}
