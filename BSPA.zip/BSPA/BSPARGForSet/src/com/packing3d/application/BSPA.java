package com.packing3d.application;

import com.packing3d.beamsearchs.beamsearchA.BeamSearchA;
import com.packing3d.beamsearchs.beamsearchB.BeamSearchB;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.state.State;
import com.packing3d.beamsearchs.beamsearchC.Fastate;
import com.packing3d.beamsearchs.beamsearchC.BeamSearchC;
import com.packing3d.filetool.FileHelper;
import com.packing3d.helper.StateHelper;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/**
 * @Author yajiewen
 * @Date 2022-07-14 10-28-59
 * @Description 根据原文, 不同的问题, 块的fillrate 使用不同的值: BR0-BR7 Minfillrate = 1 ; BR8-BR15 Minfillrate = 0.98
 * 块选择方法使用fbr 修复fbr
 */

/**
 * @Author yajiewen
 * @Date 2022-10-22 22-00-36
 * @Description 优化使用配置文件类每次不需要再改Main
 */
public class BSPA {
    public static void main(String[] args) throws IOException, InterruptedException {
        // args : 输入文件路径 输出文件路径 搜索时间 最大线程 参数a 参数b 参数minfillrate
        InitHelper.RUN_TIME = Integer.parseInt(args[2]);
        InitHelper.thread = Integer.parseInt(args[3]);
        InitHelper.a = Double.parseDouble(args[4]);
        InitHelper.b = Double.parseDouble(args[5]);
        InitHelper.MinFillRate = Double.parseDouble(args[6]);
        InitHelper.printParameter();
        //获取文件夹中的文件数量
        File foder = new File(args[0]);
        int number = foder.listFiles().length;
        for (int i = 1; i <= number/2; i++) {
            bsparun(args[0], args[1], String.valueOf(i));
            System.gc();
            TimeUnit.MILLISECONDS.sleep(2000);
        }

    }

    /**
     * @Author yajiewen
     * @Date 2023-02-22 21-04-25
     * @Description
     */

    public static void bsparun(String inputPath, String outputPath, String id) {
        // 创建输出文件夹
        File outputPathFolder = new File(outputPath);
        if (!outputPathFolder.exists() && !outputPathFolder.isDirectory()) {
            System.out.println("创建输出文件夹");
            outputPathFolder.mkdir();
        }
        FileWriter fileWriter = null;
        String binInputPath, itemInputPath;

        // 创建结果输出文件
        File folder = new File(inputPath);
        try {
            fileWriter = new FileWriter(outputPath +File.separator+ "problem" + id + ".txt");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File[] fileNames = folder.listFiles();

        double totalRunTime = 0;

        binInputPath = inputPath + File.separator +"bins"+id+".csv";
        itemInputPath = inputPath + File.separator +"items"+id+".csv";
        // 开始获取problem
        FileHelper fileHelper = new FileHelper(binInputPath, itemInputPath);
        ArrayList<Problem> problemList = null;
        try {
            problemList = fileHelper.getProblems();
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (Problem problem : problemList) {

            State state = BeamSearchA.run(problem, InitHelper.RUN_TIME * 1000, InitHelper.MinFillRate, false);
            totalRunTime += InitHelper.RUN_TIME;

            // 判断是在限制时间内是否运行玩 没有运行完则增加时间 每次增加10秒
            final int[] time = {0};
            while (state == null) {
                time[0] += 10;
                System.out.println("限制时间内未跑完一个解 A搜索" +  "设置运行时间为 " + (InitHelper.RUN_TIME + time[0]) + " s");

                state = BeamSearchA.run(problem, InitHelper.RUN_TIME * 1000 + time[0] * 1000, InitHelper.MinFillRate, false);
                totalRunTime += InitHelper.RUN_TIME + time[0];
            }

            double minHigh = problem.containnerWidth;
            State bestState = null;
            Fastate bestFaState = null;
            double bestHigh = 0;
            // 如果没有装完 进行gap分级查找
            if (!State.isAllPacked(state)) {
                Fastate fastate = BeamSearchC.run(state);
                double fastateHigh = fastate.highPack; // 获取快速装填高度
                state.fastate = fastate;

                int intFastathigh = (int) Math.ceil(fastateHigh);
                int threadnum = InitHelper.thread;

                double[] allHighs = new double[intFastathigh];
                State[] allStates = new State[intFastathigh];
                Fastate[] allFaStates = new Fastate[intFastathigh];
                double[] searchHighs = new double[intFastathigh];

                Arrays.fill(allStates, state);
                Arrays.fill(allHighs, state.packHigh + fastateHigh);
                Arrays.fill(allFaStates, state.fastate);

                for (int i = 0; i < intFastathigh; i++) {
                    searchHighs[i] = minHigh + i + 1;
                }

                // 获取遍历index
                int[] index = new int[intFastathigh];
                index[0] = 0;
                for (int i = 1; i < index.length; i++) {
                    index[i] = index[i - 1] + 1;
                }
                for (int i : index) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Problem newProblem = new Problem(
                                    allStates[i].problem.containnerLength,
                                    searchHighs[i],
                                    allStates[i].problem.typeNumberOfBox,
                                    allStates[i].problem.boxList,
                                    allStates[i].problem.allBoxArea);
                            State outState = BeamSearchB.run(
                                    newProblem,
                                    InitHelper.RUN_TIME * 1000 + time[0] * 1000,
                                    InitHelper.MinFillRate,
                                    false,
                                    allStates,
                                    allHighs,
                                    i,
                                    allFaStates);
                            // 判断是在限制时间内是否运行玩 没有运行完抛出异常
                            if (outState == null) {
                                throw new IllegalArgumentException("searchB部分限制时间内未跑完一个解");
                            }
                        }
                    }).start();

                    if ((i + 1) % threadnum == 0) {
                        totalRunTime += InitHelper.RUN_TIME + time[0];
                        try {
                            TimeUnit.MILLISECONDS.sleep(InitHelper.RUN_TIME * 1000 + time[0] * 1000 + 2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                // 进行了gap递减则等待gap递减搜索结果完成线程搜索结果完成
                try {
                    totalRunTime += InitHelper.RUN_TIME + time[0];
                    TimeUnit.MILLISECONDS.sleep(InitHelper.RUN_TIME * 1000 + time[0] * 1000 + 2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


                // 结果检测
                int minIndex = 0;
                for (int i = 1; i < allHighs.length; i++) {
                    if (allHighs[minIndex] > allHighs[i]) {
                        minIndex = i;
                    }
                }
                State findBestState = allStates[minIndex];
                double findBestHigh = 0;
                if (State.isAllPacked(findBestState)) {
                    findBestHigh = findBestState.packHigh;
                } else {
                    findBestHigh = findBestState.packHigh + allFaStates[minIndex].highPack;
                }

                if (InitHelper.STATE_CHECK) {
                    for (State state1 : allStates) {
                        StateHelper.stateCheck(state1, problem);
                    }

                }

                // 保存最优结果
                bestState = allStates[minIndex];
                bestFaState = allFaStates[minIndex];
                bestHigh = findBestHigh;

            } else {
                // 保存最优解
                bestState = state;
                bestHigh = state.packHigh;
            }

            double findGap = 100 * (bestHigh / minHigh - 1);
            double containerLength = bestState.problem.containnerLength;
            double itemArea = bestState.problem.allBoxArea;
            double fillArea = 0;

            if (State.isAllPacked(bestState)) {
                fillArea = bestState.scheme.totalVolum;
            } else {
                fillArea = bestState.scheme.totalVolum + bestFaState.fascheme.totalVolume;
            }
            if (fillArea == itemArea) {  // 检测最终填充面积是否等于物品面积 等于则正确
                String outString = "runtime " + totalRunTime + "\n" +
                        "gap " + findGap + "\n" +
                        "itemArea " + itemArea + "\n" +
                        "fillArea " + fillArea + "\n" +
                        "containerLength " + containerLength + "\n" +
                        "finalBestHigh " + bestHigh + "\n" +
                        "itemArea/containerLength " + minHigh + "\n\n--------------------------------";
                try {
                    fileWriter.write(outString);
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        fileWriter.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                System.out.println(fillArea + " " + itemArea);
                throw new IllegalArgumentException("error packing area");
            }
        }

        // 关闭输出
        try {
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

