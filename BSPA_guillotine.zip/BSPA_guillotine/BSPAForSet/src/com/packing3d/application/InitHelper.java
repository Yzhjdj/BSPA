package com.packing3d.application;

/**
 * @Author yajiewen
 * @Date 2022-10-21 13-53-45
 * @Description ArrayList 容量初始化非常重要
*/
/**
 * @Author yajiewen
 * @Date 2022-10-22 22-01-55
 * @Description 增加这配置文件方便运行
*/

/**
 * @Author yajiewen
 * @Date 2022-10-23 17-04-51
 * @Description 改代码该配置现在是巅峰
*/
public class InitHelper {
    // 运行参数
    public static String TITLE  = "BSPA new score gulltion"; // 本次运行开头输出内容
    public static double MinFillRate = 1;
    public static int RUN_TIME = 30; // 一次搜索的运行时间(秒)
    public static int thread = 10;// 最大线程数量
    public static double a = 1; //参数a
    public static double b = 1.1; // 参数b
    public static boolean STATE_CHECK = true; // 是否开启状态检测

    public static void printParameter(){
        System.out.println(TITLE);
        if(STATE_CHECK){
            System.out.println("---状态检测 开启");
        }else {
            System.out.println("---状态检测 关闭");
        }

        System.out.println("---运行时间：" + RUN_TIME + "秒");
        System.out.println("---线程数量：" + thread);
        System.out.println("---a：" + a);
        System.out.println("---b：" + b);
        System.out.println("---最小填充率：" + MinFillRate);
    }
}
