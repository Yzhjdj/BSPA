package com.packing3d.beamsearchs.beamsearchA;

import com.packing3d.datastructure.space.Space;

import java.util.ArrayList;

public class SpaceHelperA {

    public static int selectSpace(ArrayList<Space> spaceArrayList){
        int minIndex = 0;
        for (int i = 0; i < spaceArrayList.size(); i++) {
            if(spaceArrayList.get(i).anchorDistance < spaceArrayList.get(minIndex).anchorDistance){
                minIndex = i;
            }
        }
        return minIndex;
    }
}
