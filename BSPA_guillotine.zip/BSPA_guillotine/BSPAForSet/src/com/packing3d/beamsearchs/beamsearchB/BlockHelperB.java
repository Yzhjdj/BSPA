package com.packing3d.beamsearchs.beamsearchB;
import com.packing3d.application.InitHelper;
import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.space.Space;
import com.packing3d.datastructure.state.State;
import java.util.ArrayList;

public class BlockHelperB {

    public static ArrayList<Block> searchViableBlock(Space space, ArrayList<Block> blockList){
        ArrayList<Block> viableBlockList = new ArrayList<>();
        for (Block block : blockList) {
            if(block.blockLenght <= space.spaceLength &&
                    block.blockWidth <= space.spaceWidth){
                viableBlockList.add(block);
            }
        }
        return viableBlockList;
    }


    public static ArrayList<Block> searchViableBlockWithNumLimitByVH(Space space, State state, int number){
        ArrayList<Block> viableBlockList = searchViableBlock(space, state.blockList);
        if(!viableBlockList.isEmpty()){
            for (Block block : viableBlockList) {
                block.fbrScore = vhScore(InitHelper.a, InitHelper.b,  block, space, state);
            }

            ArrayList<Block> returnList = new ArrayList<>();
            int minLen = Math.min(number, viableBlockList.size());
            // 简单选择排序选出最大的minL个块,放在块表前面
            for(int i = 0; i < minLen; i++){
                int maxIndex = i;
                for(int j = i + 1; j < viableBlockList.size(); j++){
                    if(viableBlockList.get(maxIndex).fbrScore < viableBlockList.get(j).fbrScore){
                        maxIndex = j;
                    }
                }
                returnList.add(viableBlockList.get(maxIndex));
                // 交换
                Block blockTemp = viableBlockList.get(i);
                viableBlockList.set(i, viableBlockList.get(maxIndex));
                viableBlockList.set(maxIndex,blockTemp);
            }
            return returnList;
        }else{
            return viableBlockList;
        }
    }

    public static double vhScore(double a, double b, Block block, Space space, State state){
        // 计算剩余物品的平均高度
        double totalHigh = 0,boxNum = 0,leftNum = 0;
        for (int i = 0; i < state.availBox.length; i++) {
            // 计算类型i的箱子的剩余数目
            leftNum = state.availBox[i] - block.neededBoxNumOfEachType[i];
            if (leftNum > 0) {
                totalHigh += leftNum * state.problem.boxList.get(i).boxWidth;
                boxNum += leftNum;
            }
        }
        double avhigh = totalHigh / boxNum;
        return a * (block.blockVolum / space.spaceVolum) +
                (block.blockLenght / space.spaceLength) +
                (block.blockWidth / space.spaceWidth)
                + b / avhigh;
    }

}
