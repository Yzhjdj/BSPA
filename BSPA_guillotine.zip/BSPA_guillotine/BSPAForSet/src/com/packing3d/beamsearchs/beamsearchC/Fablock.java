package com.packing3d.beamsearchs.beamsearchC;

import java.util.Arrays;

public class Fablock {
    public double x;
    public double y;

    public double length;
    public double width;
    public double volume;
    // 定义保存x范围的数组
    public double[] xRange;
    // 定义保存y范围的数组
    public double[] yRange;

    public Fablock(double x, double y, double length, double width) {
        this.x = x;
        this.y = y;
        this.length = length;
        this.width = width;
        this.volume = this.length * this.width;

        this.xRange = new double[2];
        // 定义保存y范围的数组
        this.yRange = new double[2];
    }

    @Override
    public String toString() {
        return "Block{" +
                "xRange=" + Arrays.toString(xRange) +
                ", yRange=" + Arrays.toString(yRange) +
                '}';
    }

    public Fablock cloneOne(){
        return new Fablock(this.x,this.y,this.length,this.width);
    }

}
