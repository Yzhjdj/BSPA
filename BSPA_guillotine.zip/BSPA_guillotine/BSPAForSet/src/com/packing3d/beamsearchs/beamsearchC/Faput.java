package com.packing3d.beamsearchs.beamsearchC;

public class Faput {
    public Fablock fablock;
    public Faspace faspace;

    public Faput(Fablock fablock, Faspace faspace) {
        this.fablock = fablock.cloneOne();
        this.faspace = faspace;

        // 更新块坐标和范围
        this.fablock.x = this.faspace.x;
        this.fablock.y = this.faspace.y;

        this.fablock.xRange[0] = this.fablock.x;
        this.fablock.xRange[1] = this.fablock.x + this.fablock.length;

        this.fablock.yRange[0] = this.fablock.y;
        this.fablock.yRange[1] = this.fablock.y + this.fablock.width;
    }
}
