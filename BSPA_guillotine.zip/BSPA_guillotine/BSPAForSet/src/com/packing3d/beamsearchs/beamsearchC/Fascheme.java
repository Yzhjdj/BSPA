package com.packing3d.beamsearchs.beamsearchC;

import com.packing3d.datastructure.scheme.Put;
import com.packing3d.datastructure.scheme.Scheme;

import java.util.ArrayList;

public class Fascheme {
    public ArrayList<Faput> faputList;
    public double totalVolume;

    public Fascheme() {
        this.faputList = new ArrayList<>();
        this.totalVolume = 0;
    }

    public void addFaput(Faput faput){
        faputList.add(faput);
        totalVolume += faput.fablock.volume;
    }

    // 克隆对象
    public Fascheme cloneObj(){
        Fascheme scheme = new Fascheme();
        scheme.totalVolume = this.totalVolume;
        for (Faput put : this.faputList) {
            scheme.faputList.add(put); // 不需要克隆put
        }
        return scheme;
    }

    public void FaschemeDetect(Fascheme fascheme) {
        for (int i = 0; i < fascheme.faputList.size(); i++) {
            Faput putA = fascheme.faputList.get(i);
            Fablock fablock1 = putA.fablock;

            for (int j = i + 1; j < fascheme.faputList.size(); j++) {
                Faput putB = fascheme.faputList.get(j);
                Fablock fablock2 = putB.fablock;
                if (fablock1 != fablock2){
                    boolean isIntersection = isBlockIntersectionFa(fablock1, fablock2);
                    if (isIntersection) {
                        System.out.println("@@@FA块有交叠");
                        throw new IllegalArgumentException("@@@FA块有交叠");
                    }
                }
            }

        }
    }

    public static boolean isBlockIntersectionFa(Fablock blockA, Fablock blockB){
        double[] ixRange = new double[2];
        double[] iyRange = new double[2];
        // x
        if(blockA.xRange[1] < blockB.xRange[0] || blockB.xRange[1] < blockA.xRange[0]){
            return false;
        }else {
            ixRange[0] = Math.max(blockA.xRange[0], blockB.xRange[0]);
            ixRange[1] = Math.min(blockA.xRange[1], blockB.xRange[1]);
        }
        // y
        if(blockA.yRange[1] < blockB.yRange[0] || blockB.yRange[1] < blockA.yRange[0]){
            return false;
        }else {
            iyRange[0] = Math.max(blockA.yRange[0], blockB.yRange[0]);
            iyRange[1] = Math.min(blockA.yRange[1], blockB.yRange[1]);
        }

        // 排除体积为0的情况
        if(ixRange[0] == ixRange[1] || iyRange[0] == iyRange[1]){
            return false;
        }
        System.out.println(blockA);
        System.out.println(blockB);
        if(blockA == blockB){
            System.out.println("@@@地址相同");
        }
        return true;
    }
}
