package com.packing3d.beamsearchs.beamsearchC;

import java.util.ArrayList;

public class Faspace {
    public double x;
    public double y;

    public double length;
    public double width;  // 高度

    public Faspace(double x, double y, double faspaceLength) {
        this.x = x;
        this.y = y;
        this.length = faspaceLength;
        this.width = Double.MAX_VALUE;
    }

    // 装入块后更新
    public static ArrayList<Faspace> faMinus(Faspace faspace, Fablock fablock){
        double x1,y1,length1;
        double x2,y2,length2;
        // 把块放在0号点
        fablock.x = faspace.x;
        fablock.y = faspace.y;
        // 空间1
        x1 = fablock.x;
        y1 = fablock.y + fablock.width;
        length1 = fablock.length;

        // 空间2
        x2 = fablock.x + fablock.length;
        y2 = fablock.y;
        length2 = faspace.length - fablock.length;

        ArrayList<Faspace> faspaceArrayList = new ArrayList<>();
        if(length1 > 0){
            faspaceArrayList.add(new Faspace(x1,y1,length1));
        }
        if(length2 > 0){
            faspaceArrayList.add(new Faspace(x2,y2,length2));
        }
        return faspaceArrayList;
    }
}
