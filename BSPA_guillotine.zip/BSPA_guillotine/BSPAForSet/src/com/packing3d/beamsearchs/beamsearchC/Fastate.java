package com.packing3d.beamsearchs.beamsearchC;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.state.State;
import com.packing3d.helper.ResourceHelper;

import java.util.ArrayList;
import java.util.Collections;

public class Fastate {
    public Fascheme fascheme;
    public ArrayList<Faspace> faspaceArrayList;
    public ArrayList<Fablock> fablockArrayList;
    double greedyScore = 0;
    public Problem problem;
    public double highPack = 0;

    public Fastate() {
        this.fascheme = new Fascheme();
        this.faspaceArrayList = new ArrayList<>();
        this.fablockArrayList = new ArrayList<>();
    }

    public static Fastate getInitFastate(State state){
        Fastate iniFaState = new Fastate();
        iniFaState.problem = state.problem;
        // 获取空间
        iniFaState.faspaceArrayList.add(new Faspace(0,0,state.problem.containnerLength));
        // 获取剩余物品
        for (int i = 0; i < state.availBox.length; i++) {
            for(int j = 0; j < state.availBox[i]; j++){
                iniFaState.fablockArrayList.add(new Fablock(0,0, state.problem.boxList.get(i).boxLength ,state.problem.boxList.get(i).boxWidth));
            }
        }
        return iniFaState;
    }

    public void renewFastate(Fablock fablock, int faspaceIndex){
        this.fascheme.addFaput(new Faput(fablock,this.faspaceArrayList.get(faspaceIndex)));
        Faspace faspace = this.faspaceArrayList.remove(faspaceIndex);
        this.faspaceArrayList.addAll(Faspace.faMinus(faspace,fablock));
        this.fablockArrayList.remove(fablock);
    }

    // 获取新的状态(在复制的上面更新)
    public static Fastate getNewFaState(Fastate stateOld, Fablock block, int selectedSpaceIndex){
        Fastate newState = stateOld.cloneObj();
        // 更新资源相关
        newState.renewFastate(block,selectedSpaceIndex);
        return newState;
    }

    // 用于克隆state ,搜索阶段需要克隆
    public Fastate cloneObj(){
        Fastate fastate = new Fastate();
        // 复制空间栈内容
        fastate.faspaceArrayList.addAll(this.faspaceArrayList);
        // 复制块表内容
        fastate.fablockArrayList.addAll(this.fablockArrayList);
        fastate.fascheme = this.fascheme.cloneObj();
        fastate.greedyScore = this.greedyScore;
        fastate.highPack = this.highPack;
        fastate.problem = this.problem;
        return fastate;
    }

    // 获取装填高度
    public void getHightOfPack(){
        // 获取所有块的最高点y坐标
        ArrayList<Double> maxYs = new ArrayList<>();
        for (Faput faput : this.fascheme.faputList) {
            maxYs.add(faput.fablock.yRange[1]);
        }
         this.highPack = Collections.max(maxYs);
    }
}
