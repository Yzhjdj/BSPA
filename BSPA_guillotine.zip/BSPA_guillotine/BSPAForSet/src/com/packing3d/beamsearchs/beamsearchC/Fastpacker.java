package com.packing3d.beamsearchs.beamsearchC;

import com.packing3d.datastructure.state.State;

import java.util.ArrayList;

public class Fastpacker {

    public static Fastate doPacking(State state){
        //生成初始状态
        Fastate iniFaState = Fastate.getInitFastate(state);
        // 开始装填
        while(!iniFaState.faspaceArrayList.isEmpty() || !iniFaState.fablockArrayList.isEmpty()){
            if(iniFaState.faspaceArrayList.isEmpty() && !iniFaState.fablockArrayList.isEmpty()){ // 没有空间了 在顶部生成一个新空间
                iniFaState.getHightOfPack();
                double y = iniFaState.highPack;
                iniFaState.faspaceArrayList.add(new Faspace(0,y,state.problem.containnerLength));
            }
            //选择一个空间
            int faSpaceIndex = faSpaceSelecter(iniFaState);
            // 选择一个块
            Fablock fablock = fablockSelecter(iniFaState, iniFaState.faspaceArrayList.get(faSpaceIndex));
            if(fablock != null){
                // 装入块更新状态
                iniFaState.renewFastate(fablock,faSpaceIndex);
            }else{
                iniFaState.faspaceArrayList.remove(faSpaceIndex);
            }
        }
        return  iniFaState;
    }

    // 空间选择方法
    public static int faSpaceSelecter(Fastate fastate){
        // 先找出位置最低的空间
        ArrayList<Faspace> lowList = new ArrayList<>();
        double miny = fastate.faspaceArrayList.get(0).y;
        for (Faspace faspace : fastate.faspaceArrayList) {
            if(miny > faspace.y){
                miny = faspace.y;
            }
        }

        for (Faspace faspace1 : fastate.faspaceArrayList) {
            if(faspace1.y == miny){
                lowList.add(faspace1);
            }
        }

        // 在位置最低的空间里面找出位置最左边的空间
        int minxIndex = 0;
        for (int i = 1; i < lowList.size(); i++) {
            if(lowList.get(i).x < lowList.get(minxIndex).x){
                minxIndex = i;
            }
        }
        return minxIndex;
    }
    // 块选择方法
    public static Fablock fablockSelecter(Fastate fastate, Faspace faspace){
        // 找出所有能放入空间中的块
        ArrayList<Fablock> feasibleBlocks = new ArrayList<>();
        for (Fablock fablock : fastate.fablockArrayList) {
            if(fablock.length <= faspace.length){
                feasibleBlocks.add(fablock);
            }
        }

        if (feasibleBlocks.isEmpty()){
            return null;
        }
        // 找出feasibleblocks中高度最高的块
        Fablock highestBlock = feasibleBlocks.get(0);
        for (Fablock feasibleBlock : feasibleBlocks) {
            if(feasibleBlock.width > highestBlock.width){
                highestBlock = feasibleBlock;
            }
        }
        return highestBlock;
    }
}
