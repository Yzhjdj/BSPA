package com.packing3d.datastructure.block;

import com.packing3d.datastructure.space.Space;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Author yajiewen
 * @Date 2022-04-04 18-07-52
 * @Description 添加根据anchor corner 更新八点坐标,更新equals 和hashcode
*/
/**
 * @Author yajiewen
 * @Date 2022-11-05 10-18-03
 * @Description 添加boxNum变量，便于VCS评价函数使用
*/
public class Block {
    public int[] neededBoxNumOfEachType; // 该复杂快所需要的各种类别箱子的数目(下标比表示类别)
    public int boxNum; // 块所包含的箱子数
    public int typeNumberOfBox; // 用于遍历
    public double blockLenght; // 复杂块的长度
    public double blockWidth; // 复杂块的宽度
    public double boxVolum; // 块中箱子的体积
    public double blockVolum; // 块的体积
    public double fbrScore; // 用于存储块经过fbr得到的分数

    public double superficialArea; // 在2维里面用于记录快的长和宽的和

    // 定义一个二维数组来保存四点坐标
    public double[][] eightCoordinate;
    // 定义保存x范围的数组
    public double[] xRange;
    // 定义保存y范围的数组
    public double[] yRange;

    /**
     * @Author yajiewen
     * @Date 2022-10-19 22-57-17
     * @Description 添加方便的构造函数(不带复杂度)
    */
    /**
     * @Author yajiewen
     * @Date 2022-11-05 10-20-27
     * @Description 添加计算块中箱子数目的方法
    */
    /**
     * @Author yajiewen
     * @Date 2023-02-17 20-23-59
     * @Description 添加块体积,和面积
    */
    public Block(int typeNumberOfBox, double blockLenght, double blockWidth, double boxVolum, int[] neededBoxNumOfEachType){
        // 在构造函数里面分配空间
        // 坐标空间
        eightCoordinate = new double[4][2];
        // x范围空间
        xRange = new double[2];
        // y范围空间
        yRange = new double[2];
        // 开始为8个变量赋值
        this.typeNumberOfBox = typeNumberOfBox;
        this.blockLenght = blockLenght;
        this.blockWidth = blockWidth;
        this.boxVolum = boxVolum;
        this.blockVolum = blockLenght * blockWidth;
        this.neededBoxNumOfEachType = neededBoxNumOfEachType;
        this.superficialArea = this.blockLenght + this.blockWidth;
        getBoxNum(); // 获取箱子数
    }

    /**
     * @Author yajiewen
     * @Date 2022-11-05 10-19-04
     * @Description 计算块所包含的箱子数
    */
    public void getBoxNum(){
        this.boxNum = 0;
        for (int i = 0; i < this.neededBoxNumOfEachType.length; i++) {
            this.boxNum += this.neededBoxNumOfEachType[i];
        }
    }

    public Block(int typeNum){
        neededBoxNumOfEachType = new int[typeNum];
        typeNumberOfBox = typeNum;
        // 在构造函数里面分配空间
        // 坐标空间
        eightCoordinate = new double[4][2];
        // x范围空间
        xRange = new double[2];
        // y范围空间
        yRange = new double[2];
    }

    // 使用范围生成coverBlock 的构造函数(coverBlock 在更新交叠空间时候使用, 只需用到八点坐标,其他信息用不到)
    public Block(double[] xRange, double[] yRange){
        // 坐标空间
        eightCoordinate = new double[4][2];
        // x范围空间
        this.xRange = new double[2];
        // y范围空间
        this.yRange = new double[2];

        blockLenght = xRange[1] - xRange[0];
        blockWidth = yRange[1] - yRange[0];
        initCoordinateAndRange(xRange[0], yRange[0]);
    }

    // 根据anchor corner 初始化块的八点坐标
    public void initCoordinateAndRangeByAnchorCorner(Space space){
        if(space.anchorCorner == 0){
            initCoordinateAndRange(space.locationX, space.locationY);
        }else if(space.anchorCorner == 1){
            // 根据1点坐标 求出块0 点处的坐标
            double oX = space.eightCoordinate[1][0] - blockLenght;
            double oY = space.eightCoordinate[1][1];
            initCoordinateAndRange(oX,oY);
        }else if(space.anchorCorner == 2){
            double oX = space.eightCoordinate[2][0] - blockLenght;
            double oY = space.eightCoordinate[2][1] - blockWidth;
            initCoordinateAndRange(oX,oY);
        }else if(space.anchorCorner == 3){
            double oX = space.eightCoordinate[3][0];
            double oY = space.eightCoordinate[3][1] - blockWidth;
            initCoordinateAndRange(oX,oY);
        }
    }

    // 以0点坐标为基准,自动初始化八点坐标和范围(该方法在前面9个变量赋值完成后调用)
    public void initCoordinateAndRange(double oX, double oY){
        // 获取8点坐标
        eightCoordinate[0][0] = oX;
        eightCoordinate[0][1] = oY;

        eightCoordinate[1][0] = eightCoordinate[0][0] + blockLenght;
        eightCoordinate[1][1] = eightCoordinate[0][1];

        eightCoordinate[2][0] = eightCoordinate[0][0] + blockLenght;
        eightCoordinate[2][1] = eightCoordinate[0][1] + blockWidth;

        eightCoordinate[3][0] = eightCoordinate[0][0];
        eightCoordinate[3][1] = eightCoordinate[0][1] + blockWidth;

        // 获取x,y,z 范围
        xRange[0] = eightCoordinate[0][0];
        xRange[1] = eightCoordinate[1][0];

        yRange[0] = eightCoordinate[0][1];
        yRange[1] = eightCoordinate[3][1];

    }



    /**
     * @Author yajiewen
     * @Date 2022-11-05 10-26-19
     * @Description 修改克隆函数，优化比必要步骤，添加克隆坐标
    */
    public Block cloneOne(){

        Block block = new Block(this.typeNumberOfBox,this.blockLenght,this.blockWidth, this.boxVolum,this.neededBoxNumOfEachType);
        // 开始复制坐标范围
        for(int i = 0; i < 4; i++){
            for(int j = 0; j < 2; j++){
                block.eightCoordinate[i][j] = this.eightCoordinate[i][j];
            }
        }
        block.xRange[0] = this.eightCoordinate[0][0];
        block.xRange[1] = this.eightCoordinate[1][0];

        block.yRange[0] = this.eightCoordinate[0][1];
        block.yRange[1] = this.eightCoordinate[3][1];

        return block;
    }

    /**
     * @Author yajiewen
     * @Date 2023-02-21 11-59-28
     * @Description 获取旋转后的块
    */
    public Block getRotatedBlock(){
        Block block = new Block(this.typeNumberOfBox,this.blockWidth,this.blockLenght,this.boxVolum,this.neededBoxNumOfEachType);
        return block;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Block block = (Block) o;
        return Double.compare(block.blockLenght, blockLenght) == 0 && Double.compare(block.blockWidth, blockWidth) == 0  && Arrays.equals(neededBoxNumOfEachType, block.neededBoxNumOfEachType);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(blockLenght, blockWidth);
        result = 31 * result + Arrays.hashCode(neededBoxNumOfEachType);
        return result;
    }

    public Block(double blockLenght, double blockWidth, double[] xRange, double[] yRange) {
        this.blockLenght = blockLenght;
        this.blockWidth = blockWidth;
        this.xRange = xRange;
        this.yRange = yRange;
    }

    @Override
    public String toString() {
        return "Block{" +
                "xRange=" + Arrays.toString(xRange) +
                ", yRange=" + Arrays.toString(yRange) +
                '}';
    }
}
