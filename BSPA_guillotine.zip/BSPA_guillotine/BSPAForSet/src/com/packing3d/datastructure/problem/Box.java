package com.packing3d.datastructure.problem;
/**
 * @Author yajiewen
 * @Date 2022-03-09 12-10-30
 * @Description
*/ 
public class Box {
    public int boxType; // 箱子的类别
    public int boxNumber; // 该类别的箱子的数目
    public double boxLength; // 箱子的长
    public double boxWidth; // 箱子的宽
    public int isXvertical; // 长是否可竖直放置
    public int isYvertical; // 宽是否可竖直放置
    public double boxArea; //箱子面积

    public Box(int boxType, int boxNumber, double boxLength, double boxWidth, int isXvertical, int isYvertical) {
        this.boxType = boxType;
        this.boxNumber = boxNumber;
        this.boxLength = boxLength;
        this.boxWidth = boxWidth;
        this.isXvertical = isXvertical;
        this.isYvertical = isYvertical;
        this.boxArea = boxLength * boxWidth;
    }

    @Override
    public String toString() {
        return "Box{" +
                "boxType=" + boxType +
                ", boxNumber=" + boxNumber +
                ", boxLength=" + boxLength +
                ", boxWidth=" + boxWidth +
                ", isXvertical=" + isXvertical +
                ", isYvertical=" + isYvertical +
                '}';
    }
}
