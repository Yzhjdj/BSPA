package com.packing3d.datastructure.problem;

import com.packing3d.datastructure.block.Block;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @Author yajiewen
 * @Date 2022-04-04 16-51-53
 * @Description 带 容器八点坐标的problem
*/

/**
 * @Author yajiewen
 * @Date 2022-10-20 13-57-16
 * @Description 添加容器的体积,避免后面重复计算
*/
public class Problem {
    public double containnerLength;// 该问题中容器的长度
    public double containnerWidth;// 该问题中容器的宽度
    public double containnerVolume; // 容器的体积
    public int typeNumberOfBox;//箱子的类别数
    public ArrayList<Box> boxList;// 每种类别的箱子的信息构成的列表
    public double[][] containerEightCoordinate; // 容器的八点坐标
    public double allBoxArea;//item填充物品的总面积
    public double minItermArea; // item最小面积

    public ArrayList<Block> defectsList = new ArrayList<>(); // 保存每个问题的缺陷空间位置信息(缺陷当做块减掉)

    public Problem(){
        boxList = new ArrayList<Box>();
        containerEightCoordinate = new double[4][2];
    }
    // 构造函数2
    public Problem(double containnerLength,double containnerWidth,int typeNumberOfBox,ArrayList<Box> boxList ,double allBoxArea){
        containerEightCoordinate = new double[4][2];
        this.containnerLength = containnerLength;
        this.containnerWidth = containnerWidth;
        this.containnerVolume = containnerLength * containnerWidth;
        this.typeNumberOfBox = typeNumberOfBox;
        this.boxList = boxList;
        this.allBoxArea = allBoxArea;

        containerEightCoordinate[0][0] = 0;
        containerEightCoordinate[0][1] = 0;

        containerEightCoordinate[1][0] = containerEightCoordinate[0][0] + containnerLength;
        containerEightCoordinate[1][1] = containerEightCoordinate[0][1];

        containerEightCoordinate[2][0] = containerEightCoordinate[0][0] + containnerLength;
        containerEightCoordinate[2][1] = containerEightCoordinate[0][1] + containnerWidth;

        containerEightCoordinate[3][0] = containerEightCoordinate[0][0];
        containerEightCoordinate[3][1] = containerEightCoordinate[0][1] + containnerWidth;
        // 计算最小物品面积
        minItermArea = boxList.get(0).boxLength * boxList.get(0).boxLength;
        for (int i = 1; i < boxList.size(); i++) {
            if(minItermArea > boxList.get(i).boxArea){
                minItermArea = boxList.get(i).boxArea;
            }
        }
    }

    @Override
    public String toString() {
        return "Problem{" +
                "containnerLength=" + containnerLength +
                ", containnerWidth=" + containnerWidth +
                ", containnerVolume=" + containnerVolume +
                ", typeNumberOfBox=" + typeNumberOfBox +
                ", boxList=" + boxList +
                ", containerEightCoordinate=" + Arrays.toString(containerEightCoordinate) +
                ", defectsList=" + defectsList +
                '}';
    }
}
