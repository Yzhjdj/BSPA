package com.packing3d.datastructure.scheme;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.space.Space;

/**
 * @Author yajiewen
 * @Date 2022-03-12 17-18-01
 * @Description
*/ 
public class Put {
    public double minx;
    public double miny;
    public double maxx;
    public double maxy;
    public double volume;

    /**
     * @Author yajiewen
     * @Date 2022-11-05 10-36-18
     * @Description 因为一个块会被使用多次，为了避免相同对象导致的一系列问题，把块克隆后再放入put
    */
    public Put(Block block,Space space){
        this.minx = space.locationX;
        this.miny = space.locationY;
        this.maxx = this.minx + block.blockLenght;
        this.maxy = this.miny + block.blockWidth;
        this.volume = block.blockVolum;
    }

}
