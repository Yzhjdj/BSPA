package com.packing3d.filetool;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Box;
import com.packing3d.datastructure.problem.Problem;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @Author yajiewen
 * @Date 2022-04-04 17-07-28
 * @Description 更新problem 版本
*/
public class FileHelper {
    public String binInputPath, itemInputPath;// 文件路径
    public FileHelper(String binInputPath,String itemInputPath){
        this.binInputPath = binInputPath;
        this.itemInputPath = itemInputPath;
    }

    // 把文件中的问题转化为对象
    public ArrayList<Problem> getProblems() throws IOException {
        ArrayList<Problem> problemList = new ArrayList<>();
        File bin = new File(binInputPath);
        File item = new File(itemInputPath);

        if(bin.exists() && item.exists()){
            // 读取箱子信息item
            Scanner scannerItem = new Scanner(item);
            scannerItem.nextLine(); // 读取第一行
            ArrayList<Box> boxList = new ArrayList<>();
            Boolean isHas = false;
            while(scannerItem.hasNextLine()){
                String[] itemInfo = scannerItem.nextLine().trim().split(",");
                // 获取箱子信息
                double boxLength = Double.parseDouble(itemInfo[1].trim());
                double boxWidth = Double.parseDouble(itemInfo[2].trim());
                for (int i = 0; i < boxList.size(); i++) {
                    Box boxi = boxList.get(i);
                    if(boxi.boxWidth == boxWidth && boxi.boxLength == boxLength){
                        boxi.boxNumber++;
                        isHas = true;
                        break;
                    }
                }
                if (!isHas){
                    Box box = new Box(
                            Integer.parseInt(itemInfo[0].trim()),
                            1,
                            boxLength,
                            boxWidth,
                            1 ,
                            1);
                    boxList.add(box);
                }
                isHas = false;
            }
            // 获取每个问题容器信息   一行一个容器，一个容器一个问题
            Scanner scannerBin = new Scanner(bin);
            scannerBin.nextLine(); // 读取第一行
            while(scannerBin.hasNextLine()){
                String[] binInfo = scannerBin.nextLine().trim().split(",");
                double itemArea = 0;
                for (Box box : boxList) {
                    itemArea += (box.boxLength * box.boxWidth) * box.boxNumber;
                }
                double minHight = itemArea / Double.parseDouble(binInfo[1].trim()); // 计算该宽度下装入所有物品时的最小高度

                Problem problem = new Problem(Double.parseDouble(binInfo[1].trim()), minHight, boxList.size(),boxList,itemArea);  // 创建一个问题
                problemList.add(problem);
            }
        } else{
            System.out.println("文件不存在");
        }
        return problemList;
    }
}
