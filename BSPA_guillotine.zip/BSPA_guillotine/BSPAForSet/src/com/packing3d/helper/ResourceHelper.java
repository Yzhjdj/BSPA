package com.packing3d.helper;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.scheme.Put;
import com.packing3d.datastructure.space.Space;
import com.packing3d.datastructure.state.State;

import java.util.ArrayList;
import java.util.Map;

/**
 * @Author yajiewen
 * @Date 2022-04-25 12-06-56
 * @Description 优化代码
 * 更新剩余空间和剩余箱子数目
 */
public class ResourceHelper {
    /**
     * @Author yajiewen
     * @Date 2022-10-21 14-02-43
     * @Description 优化:将删除被选中空间操作移入renewResource
     */
    /**
     * @Author yajiewen
     * @Date 2022-11-05 10-41-27
     * @Description 优化把scheme的更新也放入里面
     */
    // 资源(状态)更新(传入的spaceArrayList 是顶部空间去除后的, space 是被去除的放置空间, block是放置快,)
    public static void renewResource(State state, int selectedSpaceIndex, Block block){
        // 更新scheme(首先需要更新块坐标)
        Space space = state.spaceArrayList.get(selectedSpaceIndex);
        // 把块放在空间的anchor点,根据空间anchor点坐标更新块的八点坐标
        block.initCoordinateAndRangeByAnchorCorner(space);
        state.scheme.addPut(new Put(block,space));

        // 更新箱子数目
        renewAvailBoxNum(block, state.availBox);
        // 更新块表
        renewBlockList(state);
        // 更新剩余空间
        renewSpaceListByMinus(block,selectedSpaceIndex,state.spaceArrayList,state.problem,state.blockList);
    }

    /**
     * @Author yajiewen
     * @Date 2022-06-07 10-36-15
     * @Description 剩余更新箱子数目
     */
    public static void renewAvailBoxNum(Block block, int[] availNum){
        for (int i = 0; i < availNum.length; i++) {
            availNum[i] -= block.neededBoxNumOfEachType[i];
        }
    }


    /**
     * @Author yajiewen
     * @Date 2022-10-22 21-14-11
     * @Description 新的剩余空间列表更新(非完全支撑)
     */
    public static void renewSpaceListByMinus(Block block, int selectedSpaceIndex, ArrayList<Space> spaceArrayList, Problem problem,ArrayList<Block> blockList){
        // 从空间列表中删除被选中的空间
        Space space = spaceArrayList.remove(selectedSpaceIndex);
        // 根据八点坐标得到当前被放置空间的剩余空间
        ArrayList<Space> newSpaceList = minus(space,block,problem,blockList);
        spaceArrayList.addAll(newSpaceList);

        // 删除不可以放入任何空间的空间
        ArrayList<Space> spaceArrayList1 = new ArrayList<>();
        for (Space space0 : spaceArrayList) {
            if(space0.spaceVolum >= problem.minItermArea){
                spaceArrayList1.add(space0);
            }
        }
        spaceArrayList.clear();
        spaceArrayList.addAll(spaceArrayList1);
    }

    /**
     * @Author yajiewen
     * @Date 2022-10-22 20-20-11
     * @Description space - block
     */
    /**
     * @Author yajiewen
     * @Date 2023-05-10 20-47-02
     * @Description 用于二维交叠空间的更新
    */
    public static ArrayList<Space> minus(Space space, Block block, Problem problem, ArrayList<Block> blockList){

        ArrayList<Space> outcomeSpaceList = new ArrayList<>();
/*        if(orientation.equalsIgnoreCase("h")){ //水平方向
            //da
            double locationX = space.locationX;
            double locationY = space.locationY + block.blockWidth;
            double spaceLength = space.spaceLength;
            double spaceWidth = space.spaceWidth - block.blockWidth;
            Space space1 = new Space(locationX,locationY,spaceLength,spaceWidth,problem);
            //xiao
            double locationX2 = space.locationX + block.blockLenght;
            double locationY2 = space.locationY;
            double spaceLength2 = space.spaceLength - block.blockLenght;
            double spaceWidth2 = block.blockWidth;
            Space space2 = new Space(locationX2,locationY2,spaceLength2,spaceWidth2,problem);
            outcomeSpaceList.add(space1);
            outcomeSpaceList.add(space2);
            return outcomeSpaceList;
        }else{
            //da
            double locationX = space.locationX + block.blockLenght;
            double locationY = space.locationY;
            double spaceLength = space.spaceLength - block.blockLenght;
            double spaceWidth = space.spaceWidth;
            Space space1 = new Space(locationX,locationY,spaceLength,spaceWidth,problem);
            //xiao
            double locationX2 = space.locationX;
            double locationY2 = space.locationY + block.blockWidth;
            double spaceLength2 = block.blockLenght;
            double spaceWidth2 = space.spaceWidth - block.blockWidth;
            Space space2 = new Space(locationX2,locationY2,spaceLength2,spaceWidth2,problem);
            outcomeSpaceList.add(space1);
            outcomeSpaceList.add(space2);
            return outcomeSpaceList;
        }*/

        //da
        double locationX = space.locationX;
        double locationY = space.locationY + block.blockWidth;
        double spaceLength = space.spaceLength;
        double spaceWidth = space.spaceWidth - block.blockWidth;
        Space space1 = new Space(locationX,locationY,spaceLength,spaceWidth,problem);
        //xiao
        double locationX2 = space.locationX + block.blockLenght;
        double locationY2 = space.locationY;
        double spaceLength2 = space.spaceLength - block.blockLenght;
        double spaceWidth2 = block.blockWidth;
        Space space2 = new Space(locationX2,locationY2,spaceLength2,spaceWidth2,problem);

        //da
        double locationX3 = space.locationX + block.blockLenght;
        double locationY3 = space.locationY;
        double spaceLength3 = space.spaceLength - block.blockLenght;
        double spaceWidth3 = space.spaceWidth;
        Space space3 = new Space(locationX3,locationY3,spaceLength3,spaceWidth3,problem);
        //xiao
        double locationX4 = space.locationX;
        double locationY4 = space.locationY + block.blockWidth;
        double spaceLength4 = block.blockLenght;
        double spaceWidth4 = space.spaceWidth - block.blockWidth;
        Space space4 = new Space(locationX4,locationY4,spaceLength4,spaceWidth4,problem);

        double v1 = getMaxVolumOfBlockForSpace(space1,blockList);
        double v2 = getMaxVolumOfBlockForSpace(space2,blockList);
        double v3 = getMaxVolumOfBlockForSpace(space3,blockList);
        double v4 = getMaxVolumOfBlockForSpace(space4,blockList);

        if(v1 + v2 > v3 + v4){
            outcomeSpaceList.add(space1);
            outcomeSpaceList.add(space2);
        }else{
            outcomeSpaceList.add(space3);
            outcomeSpaceList.add(space4);
        }
        return outcomeSpaceList;
    }

    public static double getMaxVolumOfBlockForSpace(Space space,ArrayList<Block> blockList){
        for (Block block : blockList) {
            if(block.blockLenght <= space.spaceLength && block.blockWidth <= space.spaceWidth){
                return block.blockVolum;
            }
        }
        return 0;
    }


    /**
     * @Author yajiewen
     * @Date 2022-06-07 11-17-46
     * @Description 更新块表 (删除不满足剩余箱子数目的块)
     */
    public static void renewBlockList(State state){
        // 删除剩余箱子不可生成的块
        for (int i = state.blockList.size() -1; i >= 0; i--) {
            // 判断剩余箱子能否生成此块
            boolean isOk = true;
            Block block1 = state.blockList.get(i);

            for (int j = 0; j < state.availBox.length; j++) {
                if(block1.neededBoxNumOfEachType[j] > state.availBox[j]){
                    isOk  = false;
                    break;
                }
            }
            if(!isOk){
                state.blockList.remove(i);
            }
        }
    }
}
