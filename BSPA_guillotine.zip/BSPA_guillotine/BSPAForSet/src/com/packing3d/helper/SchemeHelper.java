package com.packing3d.helper;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.scheme.Put;
import com.packing3d.datastructure.scheme.Scheme;
import com.packing3d.datastructure.state.State;

import java.util.ArrayList;

public class SchemeHelper {
    /**
     * @Author yajiewen
     * @Date 2022-07-23 13-21-40
     * @Description
     * 检测方面:
     * 1.所有放入块的箱子数目是否超过总的可用的箱子数目
     * 2.每一个放置是否满足块可以放入在空间内
     * 3.所有块不能有交叠
     * 4.所有空间不能有包含关系
     * 5.所有放入的块的箱子数目加上剩余箱子数目是否等于总的箱子数
     */
    /**
     * @Author yajiewen
     * @Date 2022-10-21 14-20-05
     * @Description 优化输出
    */
    public static void schemeDetecte(Scheme scheme, Problem problem, State state){
        if (hasOverlappingBoxes(scheme.putList)){
            System.out.println("块交叠@@@@@@");
        }
    }

    public static boolean isOverlapping(Put a, Put b) {
        // 检查三个轴上的投影是否有重叠
        boolean overlapX = a.maxx > b.minx && a.minx < b.maxx;
        boolean overlapY = a.maxy > b.miny && a.miny < b.maxy;

        // 如果三个轴都有重叠，则两个长方体交叠
        return overlapX && overlapY;
    }

    // 检查列表中是否存在交叠的长方体
    public static boolean hasOverlappingBoxes(ArrayList<Put> putlist) {
        int n = putlist.size();
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (isOverlapping(putlist.get(i), putlist.get(j))) {
                    return true;
                }
            }
        }
        return false;
    }

}
