package com.packing3d.helper;

import com.packing3d.datastructure.block.Block;
import com.packing3d.datastructure.problem.Box;
import com.packing3d.datastructure.problem.Problem;
import com.packing3d.datastructure.state.State;

import java.util.ArrayList;
import java.util.Arrays;

public class StateHelper {
    /**
     * @Author yajiewen
     * @Date 2022-07-23 10-20-13
     * @Description 检测整个state
    */
    public static void stateCheck(State state, Problem problem){
        SchemeHelper.schemeDetecte(state.scheme, problem, state);
    }

}
